// This is a manifest file that'll be compiled into application.js, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, vendor/assets/javascripts,
// or vendor/assets/javascripts of plugins, if any, can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// compiled file.
//
// Read Sprockets README (https://github.com/sstephenson/sprockets#sprockets-directives) for details
// about supported directives. //= require turbolinks
// //#= tinymce
// //#= tinymce-jquery 


//= require jquery
//= require jquery_ujs
//= require bootstrap
//= require jquery-migrate-1.2.1.min
//= require bootstrap-datepicker

//= require parsley
//= require dataTables/jquery.dataTables
//= require dataTables/bootstrap/3/jquery.dataTables.bootstrap
//= require dataTables/extras/dataTables.responsive

//= require jsignature
//= require spin
//= require highcharts/highstock


// SPIN PART
window.MyApp = {};

var spin_it = function(target) {
  var opts = {
    lines: 13,            // The number of lines to draw
    length: 7,            // The length of each line
    width: 4,             // The line thickness
    radius: 10,           // The radius of the inner circle
    corners: 1,           // Corner roundness (0..1)
    rotate: 0,            // The rotation offset
    color: '#000',        // #rgb or #rrggbb
    speed: 1,             // Rounds per second
    trail: 60,            // Afterglow percentage
    shadow: false,        // Whether to render a shadow
    hwaccel: false,       // Whether to use hardware acceleration
    className: 'spinner', // The CSS class to assign to the spinner
    zIndex: 2e9,          // The z-index (defaults to 2000000000)
    top: '10%',           // Top position relative to parent in px
    left: '50%'           // Left position relative to parent in px
  };

  var spinner = new Spinner(opts);
  spinner.spin(target[0]);
}

MyApp.spinner = function(target, event_target, evt){  
  target = $(target);
  event_target = $(event_target);

  event_target.on(evt, function(e) {
    spin_it(target);
  });
}


// login part
var ready;
ready = (function() {

  // Spinner settup
  new MyApp.spinner($('#right_main_content'), $('.event-button'), 'click');
  
  // add spinner to dialog box
  $('body').on('click', '#add_data_modal .btn-primary', function() {    
    if($(".parsley-form").parsley().isValid()){
      spin_it($("#add_data_modal"));  
    };    
  });


  // controlling sticky footer 
  function positionFooter() {
    var $body = $("html,body");
    $body.css({
      height: "inherit"
    })
       
    if ( ($(document.body).height()) < $(window).height()) {
      $body.css({
        height: "100%"
      })
    }else {
      $body.css({
        height: "inherit"
      })
    }
  }

  // left side clicking
  $('body').on('click', '.event-button', function() {
    url = $(this).data("url");
    label = $(this).html();
    ul = $(".event-button").parent().parent();
    ul.find('li').removeClass("active");    
    $.ajax({
      type: "GET",
      url: url    
    }).success(function( data ) {
      org_text = $("#breadcrumbs li").last().data("root-label");
      $("#breadcrumbs li").last().html(org_text + ":" + label);
      $("#breadcrumbs_xs label.caption").html(org_text + ":" + label);
      $("#right_main_content").html(data);
      
      positionFooter();
    }).fail(function(data) {
      location.href = '/authorization';
    });
    $(this).parent().addClass("active");    
  });
  
  // header top right profile button click event
  $('body').on('click', '.profile-buttn', function() {
    url = $(this).data("url");
    label = $(this).html();
    $.ajax({
      type: "GET",
      url: url    
    }).success(function( data ) {
      org_text = $("#breadcrumbs li").last().data("root-label");
      $("#breadcrumbs li").last().html(org_text+": Profile");
      $("#right_main_content").html(data);      
    }).fail(function(data) {
      location.href = '/authorization';
    });
    $(this).parent().addClass("active");
  });  

  // header top right login button click event
  $("#dropdown_login_form").submit(function(data){
    $("#dropdown_login_title").text("Attempting login...");
    $.ajax({
      url: $("#dropdown_login_form").attr("action"),
      type: 'post',
      dataType: 'json',
      data: $("#dropdown_login_form").serialize()
    }).success(function() {
        location.href = "/dashboard"
        return true;
      }).fail(function(data){
        results = data.responseJSON
        if(results.failure){
          $("#dropdown_login_title").text(results.failure);
        }else{
          $("#dropdown_login_title").text("Bad Email or Password");
        }
      });
    return false;
  });

  // home page sigin form event  
  $("#sign_in_user").submit(function(data){  
    $(".form-login-status").text("Attempting login...");
    $.ajax({
      url: $("#sign_in_user").attr("action"),
      type: 'post',
      dataType: 'json',
      data: $("#sign_in_user").serialize()
    }).success(function() {
        location.href = "/dashboard"
        return true;
      }).fail(function(data) {
        results = data.responseJSON
        if(results !== undefined && results.failure){
          $(".form-login-status").text(results.failure);
        }else{
          $(".form-login-status").text("Bad Email or Password");
        }
      });
    return false;
  });
  

  $(".mobile_burger").click(function(){
    $(".left-side .nav-tabs").slideToggle();
  });

  // confirm modal box event
  $("#confirm_modal_box .modal-footer #yes_btn").on('click', function() {
    $("form.invite-form #promote_to").val(true);
    $("form.invite-form").submit();
  });
});


// footer and left side management
$(document).ready(ready);
$(document).on("page:load", ready);

function positionFooter() {
  var $body = $("html,body");
  $body.css({
    height: "inherit"
  })
  if (($(document.body).height()) < $(window).height()){
    $body.css({
      height: "100%"
    })
  }else {
    $body.css({
      height: "inherit"
    })
  }
}

$(window).bind("load", function() {
  positionFooter();
  $(window).scroll(positionFooter).resize(positionFooter)               
});

// status management
$(document).ready(function () {
  $('body').on('click', '.btn-toggle', function() {
    $(this).find('.btn').toggleClass('active');    
    if ($(this).find('.btn-warning').size()>0) {
      $(this).find('.btn').toggleClass('btn-warning');
    }   
    
    active      = $(this).find('.active');
    status_id   = active.data("id");
    status      = active.data("status");    
    object      = active.data("type");
    url         = $(this).data("update-url");
    $.ajax({
      type: "POST",
      url: url,
      data: { status_id:status_id, status:status, object:object }
    }).done(function( data ) {
      console.log(data);
    });

    $(this).find('.btn').toggleClass('btn-default');
  });
});



// sign and site documents
$(document).ready(function () {
  $(".update-document").click(function(){    
    text = $("#textbody").html();
    var find = '<script src="resource://ember-inspector-at-emberjs-dot-com/ember-inspector/data/in-page-script.js" type="text/javascript"><\/script>';
    reg = new RegExp(find, 'g');
    text = text.replace(reg,'')
    $("#document_content").val(text);
  });
  
  $("#select_mode_file").change(function(){
    doc_mode= $(this).val();
    doc     = $(this).data("doc");
    doc_id  = $(this).data("doc-id");
    url     = $(this).data("url");
    
    if(doc_mode == '1'){
      $(".upload-form").css("display","none");
      $("#pdf_file").val("");
      $(".change-tracking").css("display","block");      
    }else{
      $(".upload-form").css("display","block");
      $(".change-tracking").css("display","none");
      positionFooter();  
    }

    $.ajax({
      type: "POST",
      url: url,
      data: {document_mode:doc_mode}
    }).done(function(data){
      console.log(data);
    });
  });


  // if pdf file select, the left label is will be change to file name 
  $("#pdf_file").change(function(){
    $(".file-name-label").text($(this).val());
  });
    

  $('body').on('click', '.btn-toggle-verify', function() {
    $(this).find('.btn').toggleClass('active');    
    if ($(this).find('.btn-warning').size()>0) {
      $(this).find('.btn').toggleClass('btn-warning');
    }

    active      = $(this).find('.active');
    status_id   = active.data("id");
    status      = active.data("status");    
    url         = $(this).data("update-url");
    if(status=="1"){
      $('#add_expiry_days').modal('show');
      $("#doc_file_id").val(status_id);
      $("#update_url").val(url);
    }
    $.ajax({
      type: "POST",
      url: url,
      data: { status_id:status_id, status:status}
    }).done(function( data ) {
      id          = data.success.id
      expire_date = data.success.expire_date
      user_name   = data.success.verified_user_name
      $("#lbl_expire_date_"+id).text(expire_date);
      $("#lbl_file_name_"+id).attr("title",user_name);
      
    });
    $(this).find('.btn').toggleClass('btn-default');
  });

  $(".add-expiry-button").click(function(){    
    status_id   = $("#doc_file_id").val();
    url         = $("#update_url").val();
    expire_date = $("#expire_date").val();
    $.ajax({
      type: "POST",
      url: url,
      data: { status_id:status_id, status:"1", expire_date:expire_date}
    }).done(function( data ) {      
      id          = data.success.id
      expire_date = data.success.expire_date
      user_name   = data.success.verified_user_name
      $("#lbl_expire_date_"+id).text(expire_date);
      $("#lbl_file_name_"+id).attr("title",user_name);
    });
    $('#add_expiry_days').modal('hide');
  });
  
  $(".unlock-document").click(function(){
    $("#unlock_document").val("true");
  });

  $(".save-lock-to-sign").click(function(){
    text = $("#textbody").html();
    var find = '<script src="resource://ember-inspector-at-emberjs-dot-com/ember-inspector/data/in-page-script.js" type="text/javascript"><\/script>';
    reg = new RegExp(find, 'g');
    text = text.replace(reg,'')
    $("#document_content").val(text);
    
    $("#lock_document").val("true");
  });  
});


