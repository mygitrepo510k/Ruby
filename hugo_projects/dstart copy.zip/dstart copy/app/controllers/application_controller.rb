class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception

  helper_method :ajax_url_suffix

  NEW_USER = "?type=new_user"

  # Public: Check if the user has his own profile or not
  # 
  # Returns boolean or redirect user to other pages
  def authenticate_verify_user
    if !current_user.present?
      redirect_to request.referrer || contact_path
    elsif !current_user.has_profile?
      flash[:error] = "Please setup your profile"
      redirect_to dashboard_profile_path + NEW_USER
    else
      return true
    end
  end

  # Public: Check if the user is super admin
  #
  # Returns true or redirect user to other pages
  def authenticate_super_admin
    return unless authenticate_verify_user 
    if current_user.super_admin?
      return true
    else
      flash[:error] = "Access is for super admin only"
      redirect_to request.referrer || contact_path
    end
  end

  # Public: Check if the user is vpd level user
  # 
  # Returns boolean or redirect user to other pages
  def authenticate_vpd_level_user
    return unless authenticate_verify_user
    if current_user.vpd_level_user?
      return true
    else
      flash[:error] = "Access is for VPD admin only"
      redirect_to request.referrer || contact_path
    end
  end


  alias_method :devise_current_user, :current_user

  # Public: Get current user if user signed in REDIS
  # 
  # Returns boolean or redirect user to other pages
  def current_user
    redis_data = REDIS.get(session_key(request.ip))
    if redis_data.blank?
      sign_out(:user) unless devise_current_user.nil?
      devise_current_user
    else
      if redis_data == Dstart::Application::CONSTS[:log_out]
        sign_out(:user)
        devise_current_user        
      elsif redis_data.include?("log_out")
        REDIS.set(session_key(request.ip), nil)
        redirect_to root_path and return
      else
        REDIS.set(session_key(request.ip), redis_data)
        REDIS.expire(session_key(request.ip), 30.minutes)
        return devise_current_user unless devise_current_user.nil?

        @current_user ||= User.where(profile_id: redis_data).first
        if @current_user.present?
          sign_in @current_user
          @current_user
        else
          devise_current_user
        end
      end
    end
  end

  def session_key(ip)
    Digest::SHA512.hexdigest("drug-sites-#{ip}")
  end

  def ajax_url_suffix
    "?type=ajax"
  end

  def to_b(string)
    string == "true"
  end
end