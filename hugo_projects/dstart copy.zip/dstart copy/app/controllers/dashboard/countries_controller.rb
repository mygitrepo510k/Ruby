class Dashboard::CountriesController < DashboardController
  before_action :authenticate_vpd_level_user, except: :provinces

  # GET /dashboard/countries/
  def index
    respond_to do |format|
      format.html{render layout: params[:type] != "ajax"}
      format.json{render json: CountryDatatable.new(view_context, current_user)}
    end    
  end

  # GET /dashboard/countries/new
  def new
    @vpd = Vpd.find(params[:vpd_id]) if params[:vpd_id].present?
    @country = Country.new
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/countries
  def create
    if current_user.super_admin?
      vpd = Vpd.find(params[:vpd_id]) if params[:vpd_id].present?
    else
      vpd = current_user.vpd
    end

    if current_user.super_admin? && !vpd.present?
      country = Country.new(country_params)
      if country.save
        data = {success:{msg: "Country Added", name: country.name}}
      else
        key, val = country.errors.messages.first
        data = {failure:{msg: country.errors.full_messages.first, element_id: "country_name"}}
      end
    else
      country     = Country.find(params[:country][:name])
      vpd_country = vpd.vpd_countries.build(country: country)
      if vpd_country.save
        data = {success:{msg: "Country Added", name: vpd_country.name}}
      else
        key, val = vpd_country.errors.messages.first
        data = {failure:{msg: vpd_country.errors.full_messages.first, element_id: "country_name"}}
      end
    end

    render json: data
  end

  # GET /dashboard/countries/provinces
  def provinces
    @vpd_country = VpdCountry.find(params[:vpd_country])
    render layout: false    
  end

  private

  def country_params
    code = params[:country][:name]
    name = Carmen::Country.coded(code).name
    params[:country][:code] = code
    params[:country][:name] = name
    params.require(:country).permit(:code, :name)    
  end
end