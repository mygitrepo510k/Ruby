class Dashboard::DocumentsController < DashboardController
  before_action :get_document, except: [:new, :create]
  

  # GET /dashboard/sites/:site_id/documents/new
  def new
    @document   = Document.new
    @site       = Site.find(params[:site_id])
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/sites/:site_id/documents
  def create
    @site       = Site.find(params[:site_id])
    binder      = @site.binder
    trial_doc   = TrialDocument.find(params[:document][:trial_document_id])
    due_date = (Time.now + trial_doc.due_days.day).to_date if trial_doc.due_days.present?
    document = trial_doc.documents.build(binder:binder, document_type:trial_doc.document_type, name:trial_doc.name, content:trial_doc.content, due_date:due_date, due_days:trial_doc.due_days, play_book:trial_doc.play_book, document_mode:trial_doc.document_mode)
    if document.save
      trial_doc.document_files.each do |trial_doc_file|
        document.document_files.create(file:trial_doc_file.file, verified:trial_doc_file.verified, expire_date:trial_doc_file.expire_date, verified_user:trial_doc_file.verified_user)
      end      
      @site.users.each do |user|
        UserMailer.add_new_document_notification(user, document).deliver
      end
      render json: {success:{msg: "Site Document Added", name: document.name}}
    else
      key, val = document.errors.messages.first
      render json: {failure:{msg: document.errors.full_messages.first, element_id: "document_#{key}"}}
    end
  end

  # GET /dashboard/documents/:id/edit
  def edit
    @document_mode  = @document.document_mode == 1 ? false : true
    @edit_user_id   = current_user.id.to_s
    @edit_user_name = current_user.name
    @is_locked      = @document.sign_mode
  end

  # PATCH|PUT /dashboard/documents/:id
  def update
    users = @document.related_users.not_in(id:current_user.id.to_s)
    if params[:pdf_file].present?
      doc_file = @document.document_files.build(file:params[:pdf_file])
      unless doc_file.save
        msg = doc_file.errors.full_messages.first
      else        
        users.each do |user|
          UserMailer.attached_new_file(current_user, user, @document).deliver
        end
      end
    else
      if params[:unlock_document] == "true"
        @document.update_attributes(uploaded_document:false)
        if @document.is_signed
          if current_user.tcm_level_user?(@site)
            UserMailer.changed_document_status(@document.site_signed_user, @document).deliver if @document.site_signed_user.present?
          elsif current_user.is_site_admin?(@site)
            UserMailer.changed_document_status(@document.trial_signed_user, @document).deliver if @document.trial_signed_user.present?
          end
        end
        @document.update_attributes(trial_signed_user:nil, trial_signed_at:nil, trial_signature:nil, site_signed_at:nil, site_signature:nil, site_signed_user:nil, sign_mode:false)
      elsif params[:save_request_countersign] == "true"
        if params[:document][:trial_signature].present? and  current_user.tcm_level_user?(@site)
          @document.update_attributes(trial_signed_at:Time.now, trial_signature:params[:document][:trial_signature], trial_signed_user:current_user, trial_sign_user_name:params[:document][:trial_sign_user_name], locked_mode:true)
          users.each do |user|
            UserMailer.signed_document(current_user, user, @document).deliver
          end        
        elsif params[:document][:site_signature].present? and @site.site_only_user?(current_user)
          @document.update_attributes(site_signed_at:Time.now, site_signature:params[:document][:site_signature], site_signed_user:current_user, site_sign_user_name:params[:document][:site_sign_user_name], locked_mode:true)
          users.each do |user|
            UserMailer.signed_document(current_user, user, @document).deliver
          end
        end
      else
        due_date = params[:document][:due_date].present? ? DateTime.strptime(params[:document][:due_date],"%m/%d/%Y").to_date : nil
        if due_date.present?
          params[:document][:due_date] = due_date.strftime("%Y-%m-%d")
          params[:document][:due_days] = (due_date - @document.created_at.to_date).to_i
        end
        @document.update_attributes(params[:document].permit(:document_id, :name, :content, :document_type, :due_date, :due_days))

        if params[:lock_document] == "true"
          @document.update_attributes(sign_mode:true)          
          users.each do |user|
            UserMailer.locked_document(current_user, user, @document).deliver
          end
        end
      end
    end

    respond_to do |format|
      format.html { redirect_to action: :edit}
      format.json { render json: @document, status: :updated, location: @document}
      flash[:error] = msg if msg.present?
    end
  end  


  ################# Member Actions ###############
  #
  #
  ################################################

  # POST /dashboard/documents/:id/verify_document_file
  def verify_document_file
    doc_file = @document.document_files.find(params[:status_id])
    expire_date = params[:expire_date].present? ? DateTime.strptime(params[:expire_date],"%m/%d/%Y").to_date : nil
    
    if params[:status] == "1"
      doc_file.update_attributes(verified:true, expire_date:expire_date, verified_user: current_user)
      @document.update_attributes(verified_date:Time.now.to_date) until @document.verified_date.present?
    else
      doc_file.update_attributes(verified:false, expire_date:expire_date, verified_user_id: "")
    end
    
    expire_date = doc_file.expire_date.present? ? doc_file.expire_date.strftime("%d %b %Y") : ""
    data = {success:{msg:"updated", id:doc_file.id.to_s, expire_date:expire_date, verified_user_name:doc_file.verified_user_name}}
    
    render json: data
  end

  # POST /dashboard/documents/:id/upload_pdf_to_amazon
  def upload_pdf_to_amazon
    if params[:upload_file].present?      
      content = @document.content
      site_signature = "<div style='float:left;'><img src='#{@document.site_signature}'/><br/><label>Name : #{@document.site_signed_user_name}</label><br/><label>Signed at : #{@document.site_signed_at.present? ? @document.site_signed_at.strftime('%d %b %Y : %H') : ''}</label></div>"
      trial_signature ="<div style='float:right;'><img src='#{@document.trial_signature}'/><br/><label>Name : #{@document.trial_signed_user_name}</label><br/><label>Signed at : #{@document.trial_signed_at.present? ? @document.trial_signed_at.strftime('%d %b %Y : %H') : ''}</label></div>"
      content = content + site_signature + trial_signature
      data = Nokogiri::HTML(content)
      data.css('span.del').remove    
      @pdf_content = data.css("body").children.to_s
      
      pdf = WickedPdf.new.pdf_from_string(@pdf_content)
      save_path = Rails.root.join("#{@document.name}.pdf")
      File.open(save_path, 'wb') do |file|
        file << pdf
      end
      @document.document_files.create(file:File.open(Rails.root.join("#{@document.name}.pdf")))
      @document.update_attributes(uploaded_document:true)
    end
    redirect_to action: :edit
  end

  # GET /dashboard/documents/:id/view_pdf
  def view_pdf
    content = @document.content
    site_signature = "<div style='float:left;'><img src='#{@document.site_signature}'/></div>"
    trial_signature ="<div style='float:right;'><img src='#{@document.trial_signature}'/></div>"
    content = content + site_signature + trial_signature
    data = Nokogiri::HTML(content)
    data.css('span.del').remove    
    @pdf_content = data.css("body").children.to_s    
    respond_to do |format|
      format.html
      format.pdf do
        render :pdf => @document.name, :layout => 'pdf_layout.html.haml', :save_to_file =>Rails.root.join("#{@document.name}.pdf")
      end
    end    
  end

  # GET /dashboard/documents/:id/export_pdf
  def export_pdf
    content = @document.content    
    data = Nokogiri::HTML(content)
    data.css('span.del').remove    
    @pdf_content = data.css("body").children.to_s
    respond_to do |format|
      format.html
      format.pdf do
        render :pdf => @document.name, :layout => 'pdf_layout.html.haml'
      end
    end
    
  end

  # POST /dashboard/documents/:id/update_play_book
  def update_play_book    
    if @document.update_attributes(play_book:params[:play_book])
      data = {success:{msg:"Updated play_book", id:@document.id.to_s}}
    else
      data = {failure: {msg:@document.errors.full_messages.first}}
    end
    render json: data
  end

  # POST /dashboard/documents/:id/change_document_mode
  def change_document_mode
    document = Document.find(params[:id])
    if document.update_attributes(document_mode:params[:document_mode])
      data = {msg:"success"}
    else
      data = {msg:document.errors.full_messages.first}
    end
    render json: data
  end

  private

  def get_document
    @document = Document.find(params[:id])
    @site     = @document.binder.site
    @trial    = @site.trial
  end

  def document_params
    params.require(:document).permit()
  end
end