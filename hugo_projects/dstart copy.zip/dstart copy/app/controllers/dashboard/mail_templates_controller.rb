class Dashboard::MailTemplatesController < DashboardController
  before_action :authenticate_vpd_level_user

  # GET /dashboard/vpds/:vpd_id/mail_templates
  def index
    @vpd = Vpd.find(params[:vpd_id])
    respond_to do |format|
      format.html{ render layout: !params[:type] == "ajax" }
      format.json{ render json: VpdMailtemplateDatatable.new(view_context, @vpd) }
    end
  end

  # GET /dashboard/vpds/:vpd_id/mail_templates/new
  def new
    @mail_temp = VpdMailTemplate.new
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/vpds/:vpd_id/mail_templates
  def create
    vpd = Vpd.find(params[:vpd_id])
    mail_temp = vpd.vpd_mail_templates.build(mail_template_params)
    if mail_temp.save
      data = {success:{msg: "Mail Template Added", name: mail_temp.name}}
    else
      key, val = mail_temp.errors.messages.first
      data = {failure:{msg: mail_temp.errors.full_messages.first, element_id: "vpd_mail_template_#{key}"}}
    end
    render json: data
  end

  # GET /dashboard/vpds/:vpd_id/mail_templates/:id/edit
  def edit
    @mail_temp = VpdMailTemplate.find(params[:id])
    respond_to do |format|
      format.html
      format.js
    end
  end

  # PUT|PATCH /dashboard/vpds/:vpd_id/mail_templates/:id
  def update
    mail_temp = VpdMailTemplate.find(params[:id])
    if mail_temp.update_attributes(mail_template_params)
      data = {success:{msg: "Mail Template Updated", name: mail_temp.name}}
    else
      key, val = mail_temp.errors.messages.first
      data = {failure:{msg: mail_temp.errors.full_messages.first, element_id: "vpd_mail_template_#{key}"}}
    end
    render json: data
  end

  private

  def mail_template_params
    params.require(:vpd_mail_template).permit(:type, :name, :subject, :body)    
  end

  def confirm_vpd_admin
    unless current_user.vpd_level_user?
      redirect_to dashboard_path
    end
  end
end