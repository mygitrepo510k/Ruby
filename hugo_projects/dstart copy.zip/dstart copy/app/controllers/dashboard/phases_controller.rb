class Dashboard::PhasesController < DashboardController
  before_action :authenticate_vpd_level_user

  # GET /dashboard/phases/
  def index
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json { render json: PhaseDatatable.new(view_context, current_user) }
    end
  end

  # GET /dashboard/phases/new
  def new
    @vpd = Vpd.find(params[:vpd_id]) if params[:vpd_id].present?
    @phase = Phase.new
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/phases
  def create
    if current_user.super_admin?
      vpd = Vpd.find(params[:vpd_id]) if params[:vpd_id].present?
    else
      vpd = current_user.vpd
    end

    if current_user.super_admin? && !vpd.present?
      phase = Phase.new(phase_params)
      if phase.save
        data = {success:{msg: "Phase Added", name: phase.name}}
      else
        key, val = phase.errors.messages.first
        data = {failure:{msg: phase.errors.full_messages.first, element_id: "phase_#{key}"}}
      end
    else
      phase     = Phase.find(params[:phase][:name])
      vpd_phase = vpd.vpd_phases.build(phase: phase)
      if vpd_phase.save
        data = {success:{msg: "Phase Added", name: vpd_phase.name}}
      else
        key, val = vpd_phase.errors.messages.first
        data = {failure:{msg: vpd_phase.errors.full_messages.first, element_id: "phase_name"}}
      end
    end

    render json: data
  end

  private

  def phase_params
    params.require(:phase).permit(:name)
  end
end