class Dashboard::SitesController < DashboardController
  before_action :get_site, except: [:index, :new, :create]
  before_action :get_trial

  before_action :authenticate_verify_user
  before_action :authenticate_site_creatable_user, only: [:new, :create]
  before_action :authenticate_site_details_editable_user, only: :update
  before_action :authenticate_site_level_user, except: [:new, :create, :update]
  before_action :authenticate_site_editable_user, only: [:new_user, :user, :edit_user, :role]

  # GET /dashboard/trials/:trial_id/sites/new
  def new
    @site = Site.new
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/trials/:trial_id/sites
  def create
    site              = @trial.sites.build(site_params)
    if site.save
      trial_binder    = site.trial_binder
      binder = Binder.new(trial_binder:trial_binder, binder_id:trial_binder.binder_id, vpd:@trial.vpd, trial:@trial, site:site, vpd_binder:trial_binder.vpd_binder)
      if binder.save
        trial_binder.documents.activated_trial_documents.each do |trial_doc|
          due_date = (Time.now + trial_doc.due_days.day).to_date if trial_doc.due_days.present?
          document = trial_doc.documents.create(binder:binder, document_type:trial_doc.document_type, name:trial_doc.name, content:trial_doc.content, due_date:due_date, due_days:trial_doc.due_days, play_book:trial_doc.play_book, document_mode:trial_doc.document_mode)
          trial_doc.document_files.each do |trial_doc_file|
            document.document_files.create(file:trial_doc_file.file, verified:trial_doc_file.verified, expire_date:trial_doc_file.expire_date, verified_user:trial_doc_file.verified_user)
          end
        end        
      else
        data = {failure: {msg: binder.errors.full_messages}}
      end
      data = {success:{msg: "Site Added", name: site.site_id}}
    else
      key, val = site.errors.messages.first
      data = {failure:{msg: site.errors.full_messages.first, element_id: "site_#{key}"}}
    end

    render json: data
  end

  # GET dashboard/sites/:id/edit
  def edit
    render layout: params[:type] != "ajax"
  end

  # PUT /dashboard/sites/:id
  def update
    @site.assign_attributes(site_params)
    @site.assign_attributes(extra_fields:params[:extra_fields])

    if @site.save
      render json: {success:{msg: "Site Updated", text: "Your changes have been updated successfully.", name: @trial.trial_id}}
    else
      key, val = @site.errors.messages.first
      render json: {failure:{msg: @site.errors.full_messages.first, element_id: "site_#{key}"}}
    end
  end

  # GET /dashboard/sites/:id/users
  def users
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json { render json: SiteUserDatatable.new(view_context, current_user, @site) }
    end
  end

  # GET /dashboard/sites/:id/new_user
  def new_user
    @user = User.new
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/sites/:id/user
  def user
    user = User.where(email: params[:user][:email]).first
    p_role = params[:user][:role].to_i

    if user.present?
      render json: { failure: {msg: t("controllers.sites.user.failure_super_admin"), element_id: "user_email"}} and return if user.super_admin?
      render json: { failure: {msg: t("controllers.sites.user.failure_vpd_admin"), element_id: "user_email"}} and return if @site.trial.vpd.vpd_admin?(user)
      render json: { failure: {msg: t("controllers.sites.user.failure_trial_admin"), element_id: "user_email"}} and return if @site.trial.trial_admins.include?(user)
      render json: { failure: {msg: t("controllers.sites.user.failure_exist_user"), element_id: "user_email"}} and return if @site.users.include?(user)

      role = user.roles.build(rolify: @site, role: p_role)
      if role.save
        member_type = p_role < user.member_type ? p_role : user.member_type
        user.update_attributes(manager: current_user, member_type: member_type)
        UserMailer.invited_site_user(user, @site).deliver
        data = {success:{msg: "Invited new Site User", id: user.id.to_s, name: user.email}}
      else
        data = {failure:{msg: "Failed to invite", id: user.id.to_s, name: user.email}}
      end
    else
      password = (0...8).map { (97 + rand(26)).chr }.join
      user = User.new(email: params[:user][:email], password: password, password_confirmation: password, 
                      member_type: p_role, manager: current_user)
      role = user.roles.build(rolify: @site, role: p_role)
      if role.save
        user.skip_confirmation!
        if user.save
          data = {success:{msg: "Invited new Site User", id: user.id.to_s, name: params[:user][:email]}}
        else
          role.destroy
          data = {failure:{msg: "Failed to invite", element_id: "user_email"}}
        end
      else
        data = {failure:{msg: "Failed to invite", element_id: "user_email"}}
      end
    end
    render json: data
  end

  # GET /dashboard/sites/:id/edit_user
  def edit_user
    user = User.find(params[:user_id])
    @role = @site.roles.where(user: user).first
  end

  # PUT|PATCH /dashboard/sites/:id/role
  def role
    p_role    = params[:role][:role].to_i
    p_status  = params[:role][:status].to_i 
    role      = Role.find(params[:role][:id])
    if role.update_attributes(role: p_role, status: p_status)
      data = {success:{msg: "Edit Site User", id: role.id.to_s, name: role.email}}
    else
      key, val = role.errors.messages.first
      data = {failure:{msg: role.errors.full_messages.first, element_id: "role_#{key}"}}
    end
    render json: data
  end

  # GET /dashboard/sites/:id/documents
  def documents
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json{ render json: DocumentDatatable.new(view_context, current_user), layout: false}
    end
  end

  private

  def get_trial
    if params[:trial_id].present?
      @trial = Trial.find(params[:trial_id])
    else
      @trial = @site.trial
    end
  end

  def get_site
    @site = Site.find(params[:id])
  end

  def site_params
    vpd_country = VpdCountry.find(params[:site][:country])
    country = vpd_country.country
    country_name = country.name
    state = Carmen::Country.coded(country.code).subregions.coded(params[:site][:state_code]).name

    params[:site][:vpd_country_id] = vpd_country.id.to_s
    params[:site][:country_id] = country.id.to_s
    params[:site][:country_name] = country_name
    params[:site][:state] = state
    
    params.require(:site).permit(:site_id, :name, :country_id, :country_name, :vpd_country_id, :state_code, :state, :city, :address, :zip_code, :status, :trial_binder_id)
  end

  # Public: Check if the user is site level user
  # 
  # Returns boolean or redirect user to other pages
  def authenticate_site_level_user
    if current_user.site_level_user?(@site)
      true
    else
      flash[:error] = "Access is for Site user only"
      redirect_to request.referrer || contact_path
    end
  end

  # Public: Check if the user can edit site data
  # 
  # Returns boolean or redirect user to other pages
  def authenticate_site_editable_user
    if current_user.site_editable?(@site)
      true
    else
      flash[:error] = "Access is for Site user only"
      redirect_to request.referrer || contact_path
    end
  end

  # Public: Check if the user can create site
  # 
  # Returns boolean or redirect user to other pages
  def authenticate_site_creatable_user
    current_user.trial_editable?(@trial)
  end

  # Public: Check if the user can edit site details
  # 
  # Returns boolean or redirect user to other pages
  def authenticate_site_details_editable_user
    current_user.trial_editable?(@trial) || @site.trial_associate?(current_user)
  end
end