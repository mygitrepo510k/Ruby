class Dashboard::SponsorsController < DashboardController
  before_action :authenticate_vpd_level_user

  # GET /dashboard/sponsors/
  def index
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json { render json: SponsorDatatable.new(view_context, current_user) }
    end
  end

  # GET /dashboard/sponsors/new
  def new
    @vpd = Vpd.find(params[:vpd_id]) if params[:vpd_id].present?
    @sponsor = Sponsor.new
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/sponsors
  def create
    if current_user.super_admin?
      vpd = Vpd.find(params[:vpd_id]) if params[:vpd_id].present?
    else
      vpd = current_user.vpd
    end

    if current_user.super_admin? && !vpd.present?
      sponsor = Sponsor.new(sponsor_params)
      if sponsor.save
        data = {success:{msg: "Sponsor Added", name: sponsor.name}}
      else
        key, val = sponsor.errors.messages.first
        data = {failure:{msg: sponsor.errors.full_messages.first, element_id: "sponsor_#{key}"}}
      end
    else
      sponsor     = Sponsor.find(params[:sponsor][:name])
      vpd_sponsor = vpd.vpd_sponsors.build(sponsor: sponsor)
      if vpd_sponsor.save
        data = {success:{msg: "Sponsor Added", name: vpd_sponsor.name}}
      else
        key, val = vpd_sponsor.errors.messages.first
        data = {failure:{msg: vpd_sponsor.errors.full_messages.first, element_id: "sponsor_name"}}
      end
    end

    render json: data
  end

  private

  def sponsor_params
    params.require(:sponsor).permit(:name)
  end
end