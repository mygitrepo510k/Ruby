class Dashboard::TherapiesController < DashboardController
  before_action :authenticate_vpd_level_user

  # GET /dashboard/therapies/
  def index
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json{ render json: TherapyDatatable.new(view_context, current_user), layout: false}
    end
  end

  # GET /dashboard/therapies/new
  def new
    @vpd = Vpd.find(params[:vpd_id]) if params[:vpd_id].present?
    @therapy = Therapy.new
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/therapies
  def create
    if current_user.super_admin?
      vpd = Vpd.find(params[:vpd_id]) if params[:vpd_id].present?
    else
      vpd = current_user.vpd
    end

    if current_user.super_admin? && !vpd.present?
      therapy = Therapy.new(therapy_params)
      if therapy.save
        data = {success:{msg: "Therapy Added", name: therapy.name}}
      else
        key, val = therapy.errors.messages.first
        data = {failure:{msg: therapy.errors.full_messages.first, element_id: "therapy_#{key}"}}
      end
    else
      therapy     = Therapy.find(params[:therapy][:name])
      vpd_therapy = vpd.vpd_therapies.build(therapy: therapy)
      if vpd_therapy.save
        data = {success:{msg: "Therapy Added", name: vpd_therapy.name}}
      else
        key, val = vpd_therapy.errors.messages.first
        data = {failure:{msg: vpd_therapy.errors.full_messages.first, element_id: "therapy_name"}}
      end
    end

    render json: data
  end

  private

  def therapy_params
    params.require(:therapy).permit(:name)
  end
end