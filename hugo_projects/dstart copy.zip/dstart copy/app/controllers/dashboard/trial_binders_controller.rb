class Dashboard::TrialBindersController < DashboardController
  before_action :get_trial
  before_action :authenticate_vpd_level_user

  
  # GET /dashboard/trials/:trial_id/trial_binders/new
  def new
    @trial_binder = TrialBinder.new
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/trials/:trial_id/trial_binders
  def create
    trial_binder = @trial.trial_binders.build(binder_params)
    if trial_binder.save
      render json: {success:{msg: "VPD Binder Added", name: trial_binder.binder_id}}
    else
      key, val = trial_binder.errors.messages.first
      render json: {failure:{msg: trial_binder.errors.full_messages.first, element_id: "trial_binder_#{key}"}}
    end
  end

  # GET /dashboard/trials/:trial_id/trial_binders/:id/edit
  def edit    
    @trial_binder = TrialBinder.find(params[:id])
    @vpd          = @trial_binder.vpd
    respond_to do |format|
      format.html
      format.js
    end
  end

  # PATCH|PUT /dashboard/trials/:trial_id/trial_binders/:id
  def update
    trial_binder = TrialBinder.find(params[:id])    
    if trial_binder.update_attributes(binder_params)
      render json: {success:{msg: "VPD Binder Updated", name: trial_binder.binder_id}}
    else
      key, val = trial_binder.errors.messages.first
      render json: {failure:{msg: trial_binder.errors.full_messages.first, element_id: "trial_binder_#{key}"}}
    end
  end

  private
  # Get option params
  def binder_params
    document_ids = params[:trial_binder][:document_ids].reject{|a| a==''}
    params[:trial_binder][:document_ids] = document_ids.join(",")
    params[:trial_binder][:vpd_id] = @trial.vpd.id.to_s
    params.require(:trial_binder).permit(:binder_id, :document_ids, :vpd_id, :status)    
  end
  
  # Get Trial hook action
  def get_trial
    @trial = Trial.find(params[:trial_id])
  end

  # Public: Check if the user is trial level user
  # 
  # Returns boolean or redirect user to other pages
  def authenticate_trial_level_user
    authenticate_verify_user
    if current_user.trial_level_user?(@trial)
      true
    else
      flash[:error] = "Access is for Trial admin only"
      redirect_to request.referrer || contact_path
    end
  end

  # Public: Check if the user can edit trial data
  # 
  # Returns boolean or redirect user to other pages
  def authenticate_trial_editable_user
    if current_user.trial_editable?(@trial)
      true
    else
      flash[:error] = "Access is for Trial admin only"
      redirect_to request.referrer || contact_path
    end
  end
end