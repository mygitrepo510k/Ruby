class Dashboard::TrialDocumentsController < DashboardController
  before_action :get_trial
  before_action :authenticate_trial_level_user

  
  # GET /dashboard/trials/:trial_id/trial_documents/new
  def new
    @trial_document = TrialDocument.new
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/trials/:trial_id/trial_document
  def create
    trial_document = @trial.trial_documents.build(document_params)
    if trial_document.save
      render json: {success:{msg: "Trial document Added", name: trial_document.name}}
    else
      key, val = trial_document.errors.messages.first
      render json: {failure:{msg: trial_document.errors.full_messages.first, element_id: "trial_document_#{key}"}}
    end
  end

  def update_document_version
    trial_document            = @trial.trial_documents.find(params[:trial_document_id])
    trial_document_version    = trial_document.document_versions.where(document_version:params[:document_version].strip).first
    
    version_up                = false
    if trial_document_version.present?
      trial_document_version.assign_attributes(trial_document:trial_document, document_version:params[:document_version].strip, content:params[:document_content])
    else
      version_up              = true
      trial_document_version  = trial_document.document_versions.build(trial_document:trial_document, document_version:params[:document_version].strip, content:params[:document_content])
    end
    
    if trial_document_version.save      
      trial_document.update_attributes(document_version:params[:document_version].strip, 
                                    content:params[:document_content], 
                                    document_type:params[:doc_type],
                                    name:params[:doc_name],                                    
                                    due_days:params[:due_days])      
      data = {success:{msg:"Updated version #{trial_document_version.document_version}", id:trial_document_version.id.to_s, version:trial_document_version.document_version, version_up:version_up}}
    else      
      data = {failure: {msg:"This version is already exist"}}
    end    
    render json: data
  end

  # GET /dashboard/trials/:trial_id/trial_documents/:id/edit
  def edit
    @trial_document = TrialDocument.find(params[:id])
    @document_mode = @trial_document.document_mode == 1 ? false : true    

    @vpd = @trial_document.vpd
    if params[:document_version].present?
      trial_document_version            = @trial_document.document_versions.find(params[:document_version])
      @trial_document.content           = trial_document_version.content
      @trial_document.document_version  = trial_document_version.document_version      
    end
  end

  # PATCH|PUT /dashboard/trials/:trial_id/trial_documents/:id
  # Upload PDF file upload or update for document(type, name, mode, dueday)
  def update
    trial_document = TrialDocument.find(params[:id])
    if params[:pdf_file].present?
      doc_file = trial_document.document_files.build(file:params[:pdf_file])
      unless doc_file.save
        msg = doc_file.errors.full_messages.first
      end     
    else
      trial_document.assign_attributes(params[:trial_document].permit(:name, :content, :due_days))
      if trial_document.save
        if params[:document_version].present?
          doc_version = trial_document.document_versions.find(params[:document_version])
          doc_version.update_attributes(content:trial_document.content)
        end
        data = {success:{msg:"Updated #{trial_document.name} template", id:trial_document.id.to_s, name:trial_document.name, document_type:trial_document.document_type}}
      else
        data = {failure: {msg:trial_document.errors.full_messages.first}}
      end 
    end   
    respond_to do |format|
      format.html { redirect_to action: :edit}
      format.json { render json: trial_document, status: :updated, location: trial_document}
      flash[:error] = msg if msg.present?
    end
  end

  # POST dashboard/trials/:trial_id/trial_documents/:id/change_document_mode
  # This actions is called via ajax on VPD document page
  def change_document_mode
    trial_document = TrialDocument.find(params[:id])
    if trial_document.update_attributes(document_mode:params[:document_mode])
      data = {msg:"success"}
    else
      data = {msg:trial_document.errors.full_messages.first}
    end
    render json: data
  end

  # POST /dashboard/trials/:trial_id/trial_documents/:id/update_play_book
  # This actions is called via ajax on document template left side
  def update_play_book
    trial_document = TrialDocument.find(params[:id])
    if trial_document.update_attributes(play_book:params[:play_book])
      data = {success:{msg:"Updated play_book", id:trial_document.id.to_s}}
    else
      data = {failure: {msg:trial_document.errors.full_messages.first}}
    end
    render json: data
  end

  private
  # Get option params
  def document_params
    params[:trial_document][:vpd_id] = @trial.vpd.id.to_s
    params.require(:trial_document).permit(:document_type, :name, :vpd_id)
  end

  # Get Trial hook action
  def get_trial
    @trial = Trial.find(params[:trial_id])
  end

  # Public: Check if the user is trial level user
  # 
  # Returns boolean or redirect user to other pages
  def authenticate_trial_level_user
    authenticate_verify_user
    if current_user.trial_level_user?(@trial)
      true
    else
      flash[:error] = "Access is for Trial admin only"
      redirect_to request.referrer || contact_path
    end
  end

  # Public: Check if the user can edit trial data
  # 
  # Returns boolean or redirect user to other pages
  def authenticate_trial_editable_user
    if current_user.trial_editable?(@trial)
      true
    else
      flash[:error] = "Access is for Trial admin only"
      redirect_to request.referrer || contact_path
    end
  end
end