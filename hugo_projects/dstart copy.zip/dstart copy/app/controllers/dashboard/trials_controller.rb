class Dashboard::TrialsController < DashboardController

  before_action :get_trial, except: [:index, :new, :create] 

  before_action :authenticate_vpd_level_user, only: [:new, :create, :update]
  before_action :authenticate_trial_level_user, except: [:new, :create, :update, :edit]
  before_action :authenticate_trial_editable_user, only: [:new_admin, :admin]

  # GET /dashboard/trials/new
  def new
    @trial  = Trial.new
    @vpd = Vpd.find(params[:vpd_id]) if params[:vpd_id].present?
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/trials
  def create
    trial = current_user.trials.build(trial_params)
    if trial.save
      vpd = trial.vpd
      vpd.vpd_binders.activated_vpd_binders.each do |binder|
        tri_doc_ids  = []
        trial_binder = trial.trial_binders.create(binder_id: binder.binder_id,vpd: vpd, vpd_binder: binder)
        binder.documents.activated_vpd_documents.each do |vpd_doc|
          tri_doc     = vpd_doc.trial_documents.create(trial_binder: trial_binder, document_type: vpd_doc.document_type, name: vpd_doc.name, content: vpd_doc.content, document_version: vpd_doc.document_version, vpd: vpd, due_days: vpd_doc.due_days, play_book: vpd_doc.play_book, trial: trial, document_mode: vpd_doc.document_mode)
          DocumentVersion.create(trial_document: tri_doc)
          tri_doc_ids << tri_doc.id.to_s
          vpd_doc.document_files.each do |vpd_doc_file|
            tri_doc.document_files.create(file: vpd_doc_file.file, verified: vpd_doc_file.verified, expire_date: vpd_doc_file.expire_date, verified_user: vpd_doc_file.verified_user)
          end
        end
        trial_binder.update_attributes(document_ids:tri_doc_ids.join(","))
      end
      data = {success:{msg: "Trial Added", name: trial.trial_id}}
    else
      key, val = trial.errors.messages.first
      data = {failure:{msg: trial.errors.full_messages.first, element_id: "trial_#{key}"}}
    end
    render json: data
  end

  # GET /dashboard/trials/:id/sites
  def sites
    @user_sites = @trial.sites.activated_sites
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json { render json: SiteDatatable.new(view_context, current_user, @trial) }
    end
  end

  # GET dashboard/trials/:id/edit
  def edit
    render layout: params[:type] != "ajax"
  end

  # PUT /dashboard/trials/:id
  def update
    if current_user.vpd_level_user?
      @trial.assign_attributes(trial_params)
      @trial.assign_attributes(extra_fields:params[:extra_fields])
      if @trial.save
        @trial.sponsor = @trial.vpd_sponsor.present? ? @trial.vpd_sponsor.sponsor : nil
        @trial.save
        render json: {success:{msg: "Trial Updated", text: "Your changes have been updated successfully.", name: @trial.trial_id}}
      else
        key, val = @trial.errors.messages.first
        render json: {failure:{msg: @trial.errors.full_messages.first, element_id: "trial_#{key}"}}
      end
    else
      render json: {failure:{msg: "Trial can be updated only by vpd admin"}}
    end
  end

  # GET /dashboard/trial/:id/admins
  def admins
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json { render json: TrialAdminDatatable.new(view_context, current_user, @trial) }
    end
  end

  # GET /dashboard/trials/:id/new_admin
  def new_admin
    @user = User.new
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/trials/:id/admin
  def admin
    user = User.where(email: params[:user][:email]).first
    p_role = params[:user][:role].to_i

    if user.present?
      render json: { failure: {msg: t("controllers.trials.admin.failure_super_admin"), element_id: "user_email"}} and return if user.super_admin?
      render json: { failure: {msg: t("controllers.trials.admin.failure_vpd_admin"), element_id: "user_email"}} and return if @trial.vpd.vpd_admin?(user)
      render json: { failure: {msg: t("controllers.trials.admin.failure_trial_admin"), element_id: "user_email"}} and return if @trial.trial_admins.include?(user)

      if @trial.users.include?(user)
        if !to_b(params[:user][:promote_to])
          render json: { failure: {msg: t("controllers.trials.admin.failure_exist_user"), element_id: "user_email", need_confirm: true}} and return
        else
          user.remove_roles_in_trial(@trial)
        end
      end

      role = user.roles.build(rolify: @trial, role: p_role)
      if role.save
        member_type = p_role < user.member_type ? p_role : user.member_type
        user.update_attributes(manager: current_user, member_type: member_type)
        UserMailer.invited_trial_admin(user, @trial).deliver
        data = {success:{msg: "Invited new Trial Admin", id: user.id.to_s, name: user.email}}
      else
        data = {failure:{msg: "Failed to invite", id: user.id.to_s, name: user.email}}
      end
    else
      password = (0...8).map { (97 + rand(26)).chr }.join
      user = User.new(email: params[:user][:email], password: password, password_confirmation: password, 
                      member_type: p_role, manager: current_user)
      role = user.roles.build(rolify: @trial, role: p_role)
      if role.save
        user.skip_confirmation!
        if user.save
          data = {success:{msg: "Invited new Trial Admin", id: user.id.to_s, name: params[:user][:email]}}
        else
          role.destroy
          data = {failure:{msg: "Failed to invite", element_id: "user_email"}}
        end
      else
        data = {failure:{msg: "Failed to invite", element_id: "user_email"}}
      end
    end
    render json: data
  end

  # GET /dashboard/trials/:id/trial_documents
  def trial_documents
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json { render json: TrialDocumentDatatable.new(view_context, @trial), layout: false}    
    end
  end

  # GET /dashboard/trials/:id/trial_binders
  def trial_binders
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json { render json: TrialBinderDatatable.new(view_context, @trial), layout: false}
    end
  end

  # GET /dashboard/trials/:id/new_upload
  def new_upload
    respond_to do |format|
      format.html
      format.js
    end
  end

  # PATCH /dashboard/trials/:id/upload_config
  def upload_config
    require 'csv'
    error_list = []
    csv_file    = params[:csv_file]
    email_reg   = /^.+@.+$/

    headers     = CSV.read(csv_file.path, headers: true).headers
    headers     << "Reason"
    error_list << headers.join(",")
    have_error  = false
  
    trial = Trial.find(params[:id])
    vpd   = trial.vpd
    CSV.foreach(csv_file.path) do |row|
      if row[0] == 'Site_ID' or row.count < 10
        row << "Can't use this line"
        error_list << row
        next 
      end
      site_id         = row[0].strip
      site_name       = row[1].strip
      site_country    = row[2].strip
      site_state      = row[3].strip
      site_city       = row[4].strip
      site_address    = row[5].strip
      site_zip        = row[6].strip
      site_binder     = row[7].strip
      sa_email        = row[8].strip
      tc_email        = row[9].strip
      trial_binder    = trial.trial_binders.where(binder_id:site_binder.upcase).first
            
      if site_id.blank?
        row << "Can't blank Site_ID"
        have_error = true 
      end
      
      if site_name.blank?
        row << "Can't blank Site_Name" 
        have_error = true
      end
      
      if site_country.blank?
        row << "Can't blank Site_Country"
        have_error = true
      else
        vpd_country = vpd.vpd_countries.where({:name=>/^#{site_country}$/i}).first
        if vpd_country.nil?
          row << "Can't find Site_Country on vpd countries"
          have_error = true        
        end
      end

      if site_state.blank?
        row << "Can't blank Site_State"
        have_error = true
      end

      if site_city.blank?
        row << "Can't blank Site_City"
        have_error = true
      end

      if site_address.blank?
        row << "Can't blank Site_Address"
        have_error = true
      end

      if site_zip.blank?
        row << "Can't blank Site_ZIP"
        have_error = true
      end

      if site_binder.blank?
        row << "Can't blank Binder_Template"
        have_error = true
      end

      if trial_binder.nil?
        row << "Can't find binder on this trial"
        have_error = true
      end  

      if have_error == false
        site = trial.sites.where(site_id: site_id).first
        if site.present?
          site.assign_attributes(site_id:site_id, name:site_name, city:site_city, state:site_state, state_code:site_state, address:site_address,zip_code:site_zip,country_name: site_country,vpd_country:vpd_country,country: vpd_country.country,trial_binder:trial_binder)
        else
          site = trial.sites.build(site_id:site_id, name:site_name, city:site_city, state:site_state, state_code:site_state, address:site_address,zip_code:site_zip,country_name: site_country,vpd_country:vpd_country,country: vpd_country.country,trial_binder:trial_binder)
        end
        
        if site.save
          binder = Binder.new(trial_binder:trial_binder, binder_id:trial_binder.binder_id, vpd:vpd, trial:trial, site:site, vpd_binder:trial_binder.vpd_binder)
          if binder.save
            trial_binder.documents.not_in(status:0).each do |trial_doc|
              document = trial_doc.documents.create(binder:binder, document_type:trial_doc.document_type, name:trial_doc.name, content:trial_doc.content, due_date:trial_doc.due_date, due_days:trial_doc.due_days, play_book:trial_doc.play_book)
              trial_doc.document_files.each do |trial_doc_file|
                document.document_files.create(file:trial_doc_file.file, verified:trial_doc_file.verified, expire_date:trial_doc_file.expire_date, verified_user:trial_doc_file.verified_user)
              end
            end
          end

          if !!(sa_email =~ email_reg)
            site.add_user(sa_email, 10)
          end
          if !!(tc_email =~ email_reg)
            site.add_user(sa_email, 12)
          end
        else
          have_error = true
          row << site.errors.full_messages.first
        end
      end

      if have_error == true
        error_list << row.join(",")
      end
      have_error = false
    end

    if error_list.count > 1
      render text: error_list.join("<br>").html_safe and return
    else
      redirect_to action: :edit
    end
  end


  #private actions
  private

  def trial_params
    if params[:vpd_id].present?
      vpd = Vpd.find(params[:vpd_id])
    else
      vpd = current_user.vpd
    end
    params[:trial][:vpd_id] = vpd.id.to_s if vpd.present?
    params.require(:trial).permit(:trial_id, :title, :vpd_id, :nct, :status, :vpd_sponsor_id, :vpd_therapy_id, :vpd_phase_id)    
  end

  def get_trial
    @trial = Trial.find(params[:id])
  end

  # Public: Check if the user is trial level user
  # 
  # Returns boolean or redirect user to other pages
  def authenticate_trial_level_user
    authenticate_verify_user
    if current_user.trial_level_user?(@trial)
      true
    else
      flash[:error] = "Access is for Trial admin only"
      redirect_to request.referrer || contact_path
    end
  end

  # Public: Check if the user can edit trial data
  # 
  # Returns boolean or redirect user to other pages
  def authenticate_trial_editable_user
    if current_user.trial_editable?(@trial)
      true
    else
      flash[:error] = "Access is for Trial admin only"
      redirect_to request.referrer || contact_path
    end
  end
end