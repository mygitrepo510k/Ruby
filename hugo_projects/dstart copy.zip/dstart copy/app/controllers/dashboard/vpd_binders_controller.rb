class Dashboard::VpdBindersController < DashboardController
  before_action :get_vpd, except: [:edit, :update]
  before_action :authenticate_vpd_level_user

  # GET /dashboard/vpds/:vpd_id/vpd_binders/new
  def new
    @vpd_binder = VpdBinder.new
    respond_to do |format|
      format.html
      format.js
    end
  end

  def create    
    vpd_binder = @vpd.vpd_binders.build(vpd_binder_params)
    if vpd_binder.save
      render json: {success:{msg: "VPD Binder Added", name: vpd_binder.binder_id}}
    else
      key, val = vpd_binder.errors.messages.first
      render json: {failure:{msg: vpd_binder.errors.full_messages.first, element_id: "vpd_binder_#{key}"}}
    end
  end

  # GET /dashboard/vpd_binders/:id/edit
  def edit    
    @vpd_binder = VpdBinder.find(params[:id])
    @vpd        = @vpd_binder.vpd
    respond_to do |format|
      format.html
      format.js
    end
  end

  def update
    vpd_binder = VpdBinder.find(params[:id])    
    if vpd_binder.update_attributes(vpd_binder_params)
      render json: {success:{msg: "VPD Binder Updated", name: vpd_binder.binder_id}}
    else
      key, val = vpd_binder.errors.messages.first
      render json: {failure:{msg: vpd_binder.errors.full_messages.first, element_id: "vpd_binder_#{key}"}}
    end
  end

  #private actions
  private
  # Get VpdDocument parms
  def vpd_binder_params
    document_ids = params[:vpd_binder][:document_ids].reject{|a| a==''}
    params[:vpd_binder][:document_ids] = document_ids.join(",")
    params.require(:vpd_binder).permit(:binder_id, :document_ids, :status)
  end

  # Get VPD hook action
  def get_vpd
    @vpd = Vpd.find(params[:vpd_id])
  end
end