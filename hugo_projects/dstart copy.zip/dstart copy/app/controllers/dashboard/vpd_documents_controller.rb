class Dashboard::VpdDocumentsController < DashboardController
  before_action :get_vpd
  before_action :authenticate_vpd_level_user

  # GET /dashboard/vpds/:vpd_id/vpd_documents/
  def new
    @vpd_document = VpdDocument.new
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/vpds/:vpd_id/vpd_documents
  def create
    vpd_document = @vpd.vpd_documents.build(vpd_document_params)    
    if vpd_document.save
      document_version   = vpd_document.document_versions.create(vpd_document:vpd_document, document_version:"1.0")
      render json: {success:{msg: "VPD Document Added", name: vpd_document.name}}
    else
      key, val = vpd_document.errors.messages.first
      render json: {failure:{msg: vpd_document.errors.full_messages.first, element_id: "vpd_document_#{key}"}}
    end
  end

  def update_document_version  
    session[:file_upload] = false
    vpd_document         = @vpd.vpd_documents.find(params[:vpd_document_id])
    document_version     = vpd_document.document_versions.where(document_version: params[:document_version].strip).first
    version_up           = false
    if document_version.present?
      document_version.assign_attributes(vpd_document:vpd_document, document_version:params[:document_version].strip, content:params[:document_content])
    else
      version_up         = true
      document_version   = vpd_document.document_versions.build(vpd_document:vpd_document, document_version:params[:document_version].strip, content:params[:document_content])
    end

    if document_version.save      
      vpd_document.update_attributes(document_version:params[:document_version].strip, 
                                    content:params[:document_content], 
                                    document_type:params[:doc_type],
                                    name:params[:doc_name],
                                    due_days:params[:due_days])
      data = {success:{msg:"Updated version #{document_version.document_version}", id:document_version.id.to_s, version:document_version.document_version, version_up:version_up}}
    else
      data = {failure: {msg: document_version.errors.full_messages.first}}
    end    
    render json: data
  end

  # GET /dashboard/vpds/:vpd_id/vpd_documents/:id/edit
  def edit
    @vpd_document   = VpdDocument.find(params[:id])
    @document_mode  = @vpd_document.document_mode == 1 ? false : true    
    if params[:document_version].present?
      document_version           = @vpd_document.document_versions.find(params[:document_version])
      @vpd_document.content          = document_version.content
      @vpd_document.document_version  = document_version.document_version      
    end
  end

  # PATCH /dashboard/vpds/:vpd_id/vpd_documents/:id
  # Upload PDF file upload or update for document(type, name, mode, dueday)
  def update
    vpd_document = VpdDocument.find(params[:id])    
    if params[:pdf_file].present?
      doc_file = vpd_document.document_files.build(file:params[:pdf_file])      
      unless doc_file.save
        msg = doc_file.errors.full_messages.first
      end     
    else      
      vpd_document.assign_attributes(params[:vpd_document].permit(:document_type, :name, :content, :due_days))
      if vpd_document.save
        if params[:document_version].present?
          doc_version = vpd_document.document_versions.find(params[:document_version])
          doc_version.update_attributes(content:vpd_document.content)
        end
        data = {success:{msg:"Updated #{vpd_document.name} template", id:vpd_document.id.to_s, name:vpd_document.name, site_count:vpd_document.sites.count, status:vpd_document.status}}
      else
        data = {failure: {msg:vpd_document.errors.full_messages.first}}
      end
    end
    respond_to do |format|
      format.html { redirect_to action: :edit}
      format.json { render json: vpd_document, status: :updated, location: vpd_document}
      flash[:error] = msg if msg.present?
    end
  end


  def verify_document_file
    vpd_document = VpdDocument.find(params[:id])
    doc_file = vpd_document.document_files.find(params[:status_id])
    expire_date = params[:expire_date].present? ? DateTime.strptime(params[:expire_date],"%m/%d/%Y").to_date : nil
    
    if params[:status] == "1"
      doc_file.update_attributes(verified:true, expire_date:expire_date, verified_user: current_user)
    else
      doc_file.update_attributes(verified:false, expire_date:expire_date, verified_user_id: "")
    end
    
    expire_date = doc_file.expire_date.present? ? doc_file.expire_date.strftime("%d %b %Y") : ""
    data = {success:{msg:"updated", id:doc_file.id.to_s, expire_date:expire_date, verified_user_name:doc_file.verified_user_name}}
    
    render json: data
  end

  # POST /dashboard/vpds/:vpd_id/vpd_documents/:id/change_document_mode
  # This actions is called via ajax on VPD document page
  def change_document_mode
    vpd_document = VpdDocument.find(params[:id])
    if vpd_document.update_attributes(document_mode:params[:document_mode])
      data = {msg:"success"}
    else
      data = {msg:vpd_document.errors.full_messages.first}
    end
    render json: data
  end

  # POST /dashboard/vpds/:vpd_id/vpd_documents/:id/update_play_book
  # This actions is called via ajax on document template left side
  def update_play_book
    vpd_document = VpdDocument.find(params[:id])
    if vpd_document.update_attributes(play_book:params[:play_book])
      data = {success:{msg:"Updated play_book", id:vpd_document.id.to_s}}
    else
      data = {failure: {msg:vpd_document.errors.full_messages.first}}
    end
    render json: data
  end

  private
  # Get VpdDocument parms
  def vpd_document_params
    params.require(:vpd_document).permit(:document_type, :name)
  end

  # Get VPD hook action
  def get_vpd
    @vpd = Vpd.find(params[:vpd_id])
  end
end