class Dashboard::VpdOptionsController < DashboardController
  before_action :get_vpd, except: [:edit, :update]
  before_action :authenticate_vpd_level_user

  
  # GET   /dashboard/vpds/:vpd_id/vpd_options/new
  def new
    @option = Option.new(option_type:params[:type])
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/vpds/:vpd_id/vpd_options
  def create
    option = @vpd.options.build(option_params)
    if option.save
      render json: {success:{msg: "VPD Binder Added", name: option.option}}
    else
      key, val = option.errors.messages.first
      render json: {failure:{msg: option.errors.full_messages.first, element_id: "option_#{key}"}}
    end
  end

  private
  # Get option params
  def option_params
    params.require(:option).permit(:option, :option_type)
  end
  # Get VPD hook action
  def get_vpd
    @vpd = Vpd.find(params[:vpd_id])
  end
end