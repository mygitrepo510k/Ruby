class Dashboard::VpdsController < DashboardController
  before_action :get_vpd, except: [:index, :new, :create]

  before_action :authenticate_super_admin, only: [:index, :new, :create]
  before_action :authenticate_vpd_level_user, except: [:index, :new, :create]

  # GET /dashboard/vpds/
  def index
    session[:vpd_id] = nil
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json { render json: VpdDatatable.new(view_context, current_user) }
    end
  end

  # GET /dashboard/vpds/new
  def new
    @vpd = Vpd.new
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/vpds
  def create
    vpd = Vpd.new(vpd_params)
    
    if vpd.save
      render json: {success:{msg: "VPD Added", name: vpd.name}}
    else
      key, val = vpd.errors.messages.first
      render json: {failure:{msg: vpd.errors.full_messages.first, element_id: "vpd_#{key}"}}
    end
  end

  # GET /dashboard/vpds/:id
  def show
    redirect_to action: :trials  
  end

  # GET /dashboard/vpds/:id/trials
  def trials
    session[:vpd_id] = @vpd.id.to_s
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json { render json: TrialDatatable.new(view_context, current_user, @vpd) }
    end
  end

  # GET /dashboard/vpds/:id/users 
  def users
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json { render json: VpdUserDatatable.new(view_context, current_user, @vpd) }
    end
  end

  # GET /dashboard/vpds/:id/admins 
  def admins
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json { render json: VpdAdminDatatable.new(view_context, current_user, @vpd) }
    end
  end

  # GET /dashboard/vpds/:id/new_admin
  def new_admin
    @user = User.new
    respond_to do |format|
      format.html
      format.js
    end
  end

  # POST /dashboard/vpds/:id/admin
  def admin
    user = User.where(email: params[:user][:email]).first
    if user.present?
      render json: { failure: {msg: t("controllers.vpds.admin.failure_super_admin"), element_id: "user_email", need_confirm: false}} and return if user.super_admin?
      render json: { failure: {msg: t("controllers.vpds.admin.failure_vpd_admin") + user.vpd.name, element_id: "user_email", need_confirm: false}} and return if user.vpd_level_user?

      if @vpd.users.include?(user)
        if !to_b(params[:user][:promote_to])
          render json: { failure: {msg: t("controllers.vpds.admin.failure_exist_user"), element_id: "user_email", need_confirm: true}} and return  
        else
          user.remove_roles_in_vpd(@vpd)
        end
      end

      user.member_type = Role::ROLES[:vpd_admin] unless user.member_type < Role::ROLES[:vpd_admin]
      user.vpd = @vpd
      user.save
      UserMailer.invited_vpd_admin(user, @vpd).deliver
      data = {success:{msg: "Invited new VPD Admin", id: user.id.to_s, name: user.email}}
    else
      password = (0...8).map { (97 + rand(26)).chr }.join
      user = User.new(email: params[:user][:email], password: password, password_confirmation: password, 
                      member_type: Role::ROLES[:vpd_admin], vpd:@vpd, manager: current_user)
      user.skip_confirmation!
      if user.save
        data = {success:{msg: "Invited new VPD Admin", id: user.id.to_s, name: params[:user][:email]}}
      else
        data = {failure:{msg: "Please check your email address.", element_id: "user_email"}}
      end
    end
    render json: data
  end

  # GET /dashboard/vpds/:id/configs
  def configs
    render layout: params[:type] != "ajax"
  end

  # GET /dashboard/vpds/:id/sponsors
  def sponsors
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json { render json: SponsorDatatable.new(view_context, current_user, @vpd) }
    end
  end

  # GET /dashboard/vpds/:id/countries
  def countries
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json { render json: CountryDatatable.new(view_context, current_user, @vpd) }
    end
  end

  # GET /dashboard/vpds/:id/phases
  def phases
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json{ render json: PhaseDatatable.new(view_context, current_user, @vpd) }
    end
  end

  # GET /dashboard/vpds/:id/therapies
  def therapies
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json{ render json: TherapyDatatable.new(view_context, current_user, @vpd) }
    end
  end

  # GET /dashboard/vpds/:id/vpd_documents
  def vpd_documents    
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json { render json: VpdDocumentDatatable.new(view_context, @vpd) }
    end    
  end

  # GET /dashboard/vpds/:id/vpd_binders
  def vpd_binders
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json{ render json: VpdBinderDatatable.new(view_context, @vpd) }
    end
  end

  # GET /dashboard/vpds/:id/accounts
  def accounts
    @vpd        = Vpd.find(params[:id])
    @accounts   = @vpd.accounts
    render layout: params[:type] != "ajax"
  end

  # PATCH|PUT /dashboard/vpds/:id/set_account
  # Called on accounts page via ajax
  def set_account
    if @vpd.update_attributes(params[:vpd].permit(:base_rate, :per_complete_site, :per_incomplete_site))
      data = {success: {msg: "Your changes have been updated successfully.", id: @vpd.id.to_s}}
    else
      data = {failure: {msg: "Can't update this account values", id: @vpd.id.to_s}}
    end    
    render json: data
  end

  # GET|POST /dashboard/vpds/:id/reports
  def reports
    @vpd        = Vpd.find(params[:id])
    start_date = @vpd.created_at.to_date
    end_date = Date.today
    number_of_months = (end_date.year*12+end_date.month)-(start_date.year*12+start_date.month)
    @months = (number_of_months+1).times.each_with_object([]) do |count, array|
      date = start_date.beginning_of_month + count.months
      array << [date.strftime("%b - %Y"), date]
    end

    if request.post?
      @start_date  = params[:from_date].to_date
      @end_date    = params[:to_date].to_date
      number_of_months = (@end_date.year*12+@end_date.month)-(@start_date.year*12+@start_date.month)
      
      dates = (number_of_months+1).times.each_with_object([]) do |count, array|
        array << @start_date.beginning_of_month + count.months
      end

      @trial = params[:trial_id].present? ? Trial.where(id:params[:trial_id]).first : nil
      @user  = params[:user_id].present? ? User.where(id:params[:user_id]).first : nil
      @vpd_country  = params[:country_id].present? ? VpdCountry.where(id:params[:country_id]).first : nil

      trial_site_ids, user_site_ids, country_site_ids = [[],[],[]]

      completed_site_ids = []
      if @trial.present?
        trial_site_ids << @trial.sites.map{|st| st.id.to_s}
      else
        @vpd.trials.each do |trial|
          trial_site_ids << trial.sites.map{|st| st.id.to_s}
        end
      end

      if @user.present?
        roles = @user.roles.not_in(status:0)
        user_site_ids << roles.map{|r| r.site.present? ? r.site.id : nil}
      else
        user_site_ids = trial_site_ids
      end

      if @vpd_country.present?
        country_site_ids << @vpd_country.sites.map{|st| st.id.to_s}
      else
        country_site_ids = trial_site_ids
      end

      site_ids = trial_site_ids.flatten.compact && user_site_ids.flatten.compact && country_site_ids.flatten.compact

      months, all_sites, completed_sites, documents = [[],[],[],[]]

      dates.each do |date|
        months << date.strftime("%b")

        sites = Site.in(id:site_ids.uniq).where("return this.created_at.getFullYear() == #{date.year} && this.created_at.getMonth() == #{date.month-1}").not_in(status:0)
        uncompleted_sites = sites.reject{|site| site.completed?}
        site_count  = all_sites.last.present? ? (all_sites.last + uncompleted_sites.count) : uncompleted_sites.count
        all_sites << site_count

        completed_site_ids = []
        sites.each do |site|
          completed_site_ids << site.id.to_s if site.completed?
        end        
        completed_sites << completed_site_ids.count

        documents << @vpd.completed_documents.where("return this.verified_date.getFullYear() == #{date.year} && this.verified_date.getMonth() == #{date.month-1}").not_in(state:0).count
        
      end

      @chart_line = LazyHighCharts::HighChart.new('line') do |f|        
        f.title(:text => "REPORTS")
        # f.subtitle(text: 'Source: WorldClimate.com')
        f.yAxis(title: {
                text: 'Count'
            })
        f.xAxis(categories: months)
        # f.legend(enabled: false)        

        f.plotOptions(
          line:{
            dataLabels: {
              enabled: true
            },
            enableMouseTracking: false
          }
        )
        f.series({
            name:'Incompleted Sites',
            data:all_sites
        })
        f.series({
            name:'Completed Sites',
            data:completed_sites,
        })
        f.series({
            name:'Completed Documents',
            data:documents,
        })
        f.chart({:defaultSeriesType=>"line"})
      end
      render layout: true
    else      
      render layout: params[:type] != "ajax"
    end    
  end



  # GET /dashboard/vpds/:id/trial_fields_options
  # Called on vpd config page
  def trial_fields_options
    @vpd = Vpd.find(params[:id])    
    respond_to do |format|
      format.html{render layout: params[:type] != "ajax"}
      format.json{ render json: VpdOptionDatatable.new(view_context, @vpd, 0)}
    end
  end

  # GET /dashboard/vpds/:id/site_fields_options
  # Called on vpd config page  
  def site_fields_options
    @vpd = Vpd.find(params[:id])
    respond_to do |format|
      format.html{render layout: params[:type] != "ajax"}
      format.json{ render json: VpdOptionDatatable.new(view_context, @vpd, 1)}
    end
  end

  private

  def vpd_params
    params.require(:vpd).permit(:name)
  end

  def get_vpd
    @vpd = Vpd.find(params[:id])
  end
end