class DashboardController < ApplicationController
  before_filter :authenticate_user!
  before_action :authenticate_verify_user, only: [:index, :update_status]
  # before_action :authenticate_super_admin, only: [:users, :user_info]

  layout "dashboard"

  # GET /dashboard/index
  def index
    REDIS.set(session_key(request.ip), current_user.profile_id)
    REDIS.expire(session_key(request.ip), 30.minutes)

    unless current_user.super_admin? || current_user.vpd_level_user?
      if current_user.trials.count == 1
        if current_user.sites.count == 1
          redirect_to documents_dashboard_site_path(current_user.sites.first) and return
        else
          redirect_to dashboard_trial_sites_path(current_user.trials.first) and return
        end
      end
    end
    
    respond_to do |format|
      format.html{ render layout: params[:type] != "ajax" }
      format.json{ render json: TrialDatatable.new(view_context, current_user, nil) }      
    end
  end

  # GET /dashboard/profile
  # type - If type value is 'new_user' : profile page will be displayed without layout
  #                      not 'new_user': profile page will be displayed with dashboard layout
  def profile
    if params[:id].present?
      @user = User.find(params[:id])
    else
      @user = current_user
    end
    redirect_to root_url unless @user.present?
    render layout: false unless params[:type] == "new_user"
  end

  # PUT|PATCH /dashboard/update_profile
  def update_profile
    @user = User.find(params[:user_id])
    @user.skip_reconfirmation! 
    if params[:type] == "admin"  &&  current_user.super_admin?
      if @user.update_attributes(user_params)
        @user.reset_profile
        sign_in @user, bypass: true if current_user == @user
        render json: {success: {msg: t("controllers.dashboard.update_profile.success_msg")}} and return
      else 
        render json: {failed: {msg: @user.errors.full_messages.first}} and return
      end
    else
      respond_to do |format|
        if @user.update_attributes(user_params)
          @user.reset_profile
          sign_in @user, bypass: true if current_user == @user
          format.html { redirect_to action: :index }
          format.json { render json: @user, status: :updated }
        else
          format.html { render action: :profile }
          format.json { render json: @user.errors, status: :unprocessable_entity }
        end
      end
    end
  end

  # GET /dashboard/users (only for super admin)
  def users
    respond_to do |format|
      format.html { render layout: params[:type] != "ajax" }
      format.json { render json: UserDatatable.new(view_context, current_user) }
    end
  end

  # GET /dashboard/user_info/
  def user_info
    @user = User.find(params[:id])
    render layout: false
  end
  
  # GET /dashboard/edit_user
  def edit_user
    @user = User.find(params[:id])
    respond_to do |format|
      format.html
      format.js
    end
  end

  # PUT|PATCH /dashboard/update_user
  def update_user
    user = User.find(params[:user_id])
    if user.update_attributes(status: params[:user][:status])
      render json: {success:{msg: "Updated user", name: user.name}}
    else      
      render json: {failure:{msg: user.errors.full_messages.first}}
    end
  end

  # POST /dashboard/update_status 
  def update_status
    model = params[:object].constantize
    object = model.find(params[:status_id])
    if object.update_attributes(status: params[:status])
      render json: {success:{msg: "Updated #{params[:object]}", id: object.id.to_s}}
    else      
      render json: {failure:{msg: vpd.errors.full_messages.first}}
    end
  end

  private

  def user_params
    params.require(:user).permit(:first_name, :last_name, :salutation, :password, :password_confirmation, 
                                :organization, :position, :phone, :email, :country)    
  end
end