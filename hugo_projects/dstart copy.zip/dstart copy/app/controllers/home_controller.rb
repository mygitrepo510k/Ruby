class HomeController < ApplicationController
  skip_before_filter :verify_authenticity_token, only: :update_user

  # GET /home/index
  def index
    redis_data = REDIS.get(session_key(request.ip))    
    if redis_data.present?
      if current_user.present?
        flash[:error] = nil
        if current_user.has_profile?
          if current_user.time_span_in_DHMS[0] > 6.months / 1.day
            redirect_to dashboard_profile_path + NEW_USER
          else
            redirect_to dashboard_path
          end
        else
          redirect_to dashboard_profile_path + NEW_USER
        end
      end
    else
      sign_out(:user)
    end
  end

  # GET /home/terms
  def terms  
  end

  # GET /home/contact
  def contact    
  end

  # GET /home/authorization
  def authorization
    if current_user.present?
      redirect_to root_url
    end
  end

  # POST /api/v1/profiles/profile 
  def update_user
    user = User.where(email: params[:email]).first
    data = {failure: {msg: "can't find user"}}
    if user.present?
      user.update_attributes(
        email:                params[:email],
        profile_id:           params[:profile_id],
        first_name:           params[:first_name],
        last_name:            params[:last_name],
        salutation:           params[:salutation],
        organization:         params[:organization],
        position:             params[:position],
        phone:                params[:phone],
        country:              params[:country],
        encrypted_password:   params[:encrypted_password]
      )
      data = {success:{msg:"success", user_id:user.id}}
    end
    render json: data
  end
end