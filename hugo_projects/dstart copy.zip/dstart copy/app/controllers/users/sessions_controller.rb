class Users::SessionsController < Devise::SessionsController
  # GET /users/sign_in
  def new
    redirect_to root_url
  end

  # POST /users/sign_in
  def create
    user = User.where(email: params[:user][:email]).first 
    data = nil
    if user.present?
      if user.status == 0
        flash[:error] = "Your account was disabled"
        render json: { failure: "Your account was disabled" }, status: :not_found and return
      else
        resource = warden.authenticate!(scope: resource_name, recall: "#{controller_path}#failure")
        user.setup_profile(false) if user.invalid_profile?
        REDIS.set(session_key(request.ip), user.profile_id)
        REDIS.expire(session_key(request.ip), 30.minutes)
        sign_in_and_redirect(resource_name, resource)
        flash.delete(:error)
      end
    else
      render json: { failure: "Can't find this account" }, status: :not_found and return
    end
    
  end

  def sign_in_and_redirect(resource_or_scope, resource=nil)
    scope = Devise::Mapping.find_scope!(resource_or_scope)
    resource ||= resource_or_scope
    sign_in(scope, resource) unless warden.user(scope) == resource
    return render json: { success: true }
  end

  def failure
    return render json: { success: false, error: ["Login failed."] }
  end

  def destroy
    sign_out(:user)
    sign_out_and_redirect(resource_name)
    REDIS.set(session_key(request.ip), Dstart::Application::CONSTS[:log_out])
  end
end