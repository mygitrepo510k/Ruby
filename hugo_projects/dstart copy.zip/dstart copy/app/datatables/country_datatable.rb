class CountryDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view

  def initialize(view, user, vpd=nil)
    @view = view
    @user = user
    @vpd = vpd
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: countries.count,
      iTotalDisplayRecords: countries.total_entries,
      aaData: data.compact
    }
  end

private
  def data
    countries.map do |country|
      [
        country.name,
        country.trials.count,
        "<strong>#{country.completed_sites.count}</strong> / #{country.sites.count}".html_safe,
        country.cycle_time,
        "<div class='btn-group btn-toggle' data-update-url='/dashboard/update_status'>
            <button class='btn btn-xs #{country.status==1 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{country.id.to_s}' data-status='1' data-type='#{country.class.name}'>Yes</button>
            <button class='btn btn-xs #{country.status==0 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{country.id.to_s}' data-status='0' data-type='#{country.class.name}'>No</button>
          </div>".html_safe,
        "row_#{country.id.to_s}"
      ]
    end  
  end

  def countries
    @countries ||= fetch_countries
  end

  def fetch_countries
    if @user.super_admin?
      countries = Country.all
      countries = @vpd.vpd_countries if @vpd.present?
    elsif @user.vpd_admin?
      countries = @user.vpd.vpd_countries
    end
    
    if params[:show_option].strip == "Include disabled"
      countries = countries.activated_countries
    end
    
    if params[:sSearch].present?
      countries = countries.any_of({:name=>/^.*#{params[:sSearch]}.*$/i})
    end
    countries = countries.order("#{sort_column} #{sort_direction}").paginate(page: page, :per_page => per_page)
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[name]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end
