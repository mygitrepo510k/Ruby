class DocumentDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view

  def initialize(view, user)
    @view = view
    @user = user
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: documents.count,
      iTotalDisplayRecords: documents.present? ? documents.total_entries : 0,
      aaData: data.compact
    }
  end

private
  def data
    if @user.tcm_level_user?(@site)
      documents.map do |document|
        [        
          document.type_name,
          link_to(document.name.truncate(20), "/dashboard/documents/#{document.id.to_s}/edit", title: document.name),
          document.due_date.present? ? document.due_date.strftime("%d %b %Y") : "",
          document.expired_date,
          document.status_name.upcase,
          "<div class='btn-group btn-toggle' data-update-url='/dashboard/documents/#{document.id.to_s}/change_status'>
              <button class='btn btn-xs #{document.state==1 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{document.id.to_s}' data-status='1'>Yes</button>
              <button class='btn btn-xs #{document.state==0 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{document.id.to_s}' data-status='0'>No</button>
            </div>".html_safe,        
          "row_#{document.id.to_s}",
          "is_#{document.status_name}"
        ]
      end  
    else
      documents.map do |document|
        [        
          document.type_name,
          link_to(document.name.truncate(20), "/dashboard/documents/#{document.id.to_s}/edit", title: document.name),
          document.due_date.present? ? document.due_date.strftime("%d %b %Y") : "",
          document.expired_date,
          document.status_name.upcase,
          document.state == 1 ? "Yes" : "No",
          "row_#{document.id.to_s}",
          "is_#{document.status_name}"
        ]
      end  
    end    
  end

  def documents
    @documents ||= fetch_documents
  end

  def fetch_documents
    @site = Site.find(params[:id])
    documents = @site.documents
    if params[:sSearch].present?
      documents = documents.where(name:params[:sSearch])      
    end

    if params[:show_option].strip == "Include disabled"
      documents = documents.not_in(state:0)
    end
    documents.present? ? documents.order("#{sort_column} #{sort_direction}").paginate(page: page, :per_page => per_page) : []
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[document_type name due_date]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end
