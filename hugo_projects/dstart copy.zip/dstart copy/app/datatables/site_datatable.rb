class SiteDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view

  def initialize(view, user, trial)
    @view = view
    @user = user
    @trial = trial
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: sites.count,
      iTotalDisplayRecords: sites.total_entries,
      aaData: data.compact
    }
  end

private
  def data
    sites.map do |site|
      # next if site.binder.nil?
      [
        link_to((site.name.truncate(30) + ((site.city.present? and site.state.present?) ? "<br>#{site.city.truncate(15)}/#{site.state.truncate(15)}": "")).html_safe, "/dashboard/sites/#{site.id.to_s}/documents", title:"#{site.name}(#{site.city}/#{site.state})"),
        site.country_name,
        site.users.count,
        site.binder.state_name.upcase,
        "<b>#{site.completed_documents.count}</b>".html_safe + " / " + "#{site.documents.not_in(state:0).count}",
        "is_#{site.binder.state_name}",
        "row_#{site.id.to_s}"
      ]
    end  
  end

  def sites
    @sites ||= fetch_sites
  end

  def fetch_sites 
    unless @user.trial_level_user?(@trial)
      sites = @user.sites.where(trial: @trial)
    else
      sites = @trial.sites
    end
    
    if params[:show_option].strip == "Include disabled"
      sites = sites.activated_sites
    end
    
    if params[:sSearch].present?
      sites = sites.any_of({:name=>/^.*#{params[:sSearch]}.*$/i}, {:city=>/^.*#{params[:sSearch]}.*$/i}, {:state=>/^.*#{params[:sSearch]}.*$/i}, {:address=>/^.*#{params[:sSearch]}.*$/i}, {:zip_code=>/^.*#{params[:sSearch]}.*$/i}, {:country_name=>/^.*#{params[:sSearch]}.*$/i})
    end
    sites = sites.order("#{sort_column} #{sort_direction}").paginate(page: page, :per_page => per_page)
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[name country_name]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end