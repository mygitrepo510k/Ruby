class SiteUserDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view

  def initialize(view, user, site)
    @view = view
    @user = user
    @site = site
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: roles.count,
      iTotalDisplayRecords: roles.total_entries,
      aaData: data.compact
    }
  end

  private

  def data
    roles.map do |role|
      [
        link_to(role.user.email, "/dashboard/sites/#{@site.id.to_s}/edit_user?user_id=#{role.user.id.to_s}", remote: true) +"<br/>".html_safe+ role.user.name,
        role.user.organization,
        role.user.last_login,
        role.role_label
      ]
    end  
  end

  def roles
    @roles ||= fetch_roles
  end

  def fetch_roles
    require 'will_paginate/array'

    all_roles = @site.roles.not_in(user: @user)

    if params[:show_option].strip == "Include disabled"
      all_roles = all_roles.activated_roles
    end
    
    #all_roles = all_roles.map {|r| r.user.present? ? r : nil}.compact # Remove the roles whose user doesn't exist
      
    if params[:sSearch].present?
      all_roles = all_roles.select{|r| r.user.email =~ /#{params[:sSearch]}/}
    end

    if sort_column == "email"
      all_roles = sort_direction == 'asc' ? all_roles.sort_by!{|r| r.user.email} : all_roles.sort!{|r, u| u.user.email <=> r.user.email}
    elsif sort_column == "organization"      
      all_roles = sort_direction == 'asc' ? all_roles.sort_by!{|r| r.user.organization.present? ? r.user.organization : ''} : all_roles.sort!{|r, u| (u.user.organization.present? && r.user.organization.present?) ? u.trial.trial_id <=> r.trial.trial_id : '' <=> ''}
    elsif sort_column == "last_sign_in_at"      
      all_roles = sort_direction == 'asc' ? all_roles.sort_by!{|r| r.user.last_sign_in_at.present? ? r.user.last_sign_in_at : ''} : all_roles.sort!{|r, u| (u.user.last_sign_in_at.present? && r.user.last_sign_in_at.present?) ? u.user.last_sign_in_at.site_id <=> r.user.last_sign_in_at.site_id : '' <=> ''}
    end
    all_roles = all_roles.paginate(page: page, :per_page => per_page)
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[email organization last_sign_in_at]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end