class TherapyDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view

  def initialize(view, user, vpd=nil)
    @view = view
    @user = user
    @vpd = vpd
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: therapies.count,
      iTotalDisplayRecords: therapies.total_entries,
      aaData: data.compact
    }
  end

private
  def data    
    therapies.map do |therapy|
      [
        link_to(therapy.name, "javascript://", class: "edit-therapy-item", data:{target: "#edit_therapy_modal", toggle: :modal, id:therapy.id.to_s, status:therapy.status, name:therapy.name}),
        therapy.trials.not_in(status:0).count,
        "<strong>#{therapy.completed_sites.count}</strong> / #{therapy.sites.count}".html_safe,
        "<div class='btn-group btn-toggle' data-update-url='/dashboard/update_status'>
            <button class='btn btn-xs #{therapy.status==1 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{therapy.id.to_s}' data-status='1' data-type='#{therapy.class.name}'>Yes</button>
            <button class='btn btn-xs #{therapy.status==0 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{therapy.id.to_s}' data-status='0' data-type='#{therapy.class.name}'>No</button>
          </div>".html_safe,
        "row_#{therapy.id.to_s}"
      ]
    end  
  end

  def therapies
    @therapies ||= fetch_therapies
  end

  def fetch_therapies    
    if @user.super_admin?
      therapies = Therapy.all
      therapies = @vpd.vpd_therapies if @vpd.present?
    elsif @user.vpd_admin?
      therapies = @user.vpd.vpd_therapies
    end
    
    if params[:show_option].strip == "Include disabled"
      therapies = therapies.not_in(status:0)
    end
    
    if params[:sSearch].present?
      therapies = therapies.any_of({:name=>/^.*#{params[:sSearch]}.*$/i})
    end
    therapies = therapies.order("#{sort_column} #{sort_direction}").paginate(page: page, :per_page => per_page)
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[name]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end
