class TrialAdminDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view

  def initialize(view, user, trial)
    @view   = view
    @user   = user
    @trial  = trial
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: roles.count,
      iTotalDisplayRecords: roles.total_entries,
      aaData: data.compact
    }
  end

  private

  def data
    roles.map do |role|
      [
        role.user.email + "<br/>".html_safe + role.user.name,
        role.user.organization,
        role.user.last_login,
        role.role_label,
        "<div class='btn-group btn-toggle' data-update-url='/dashboard/update_status'>
          <button class='btn btn-xs #{role.status==1 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{role.id.to_s}' data-status='1' data-type='#{role.class.name}'>Yes</button>
          <button class='btn btn-xs #{role.status==0 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{role.id.to_s}' data-status='0' data-type='#{role.class.name}'>No</button>
        </div>".html_safe,
        "row_"+role.user.id.to_s
      ]
    end  
  end

  def roles
    @roles ||= fetch_roles
  end

  def fetch_roles
    require 'will_paginate/array'
    
    all_roles = @trial.roles.not_in(user: @user)

    if params[:show_option].strip == "Include disabled"
      all_roles = all_roles.activated_roles
    end

    #all_roles = all_roles.map {|r| r.user.present? ? r : nil}.compact # Remove the roles whose user doesn't exist

    if params[:sSearch].present?
      all_roles = all_roles.select{|r| r.user.email =~ /#{params[:sSearch]}/}
    end

    if sort_column == "email"
      all_roles = sort_direction == 'asc' ? all_roles.sort_by!{|r| r.user.email} : all_roles.sort!{|r, u| u.user.email <=> r.user.email}
    elsif sort_column == "organization"      
      all_roles = sort_direction == 'asc' ? all_roles.sort_by!{|r| r.user.organization.present? ? r.user.organization : ''} : all_roles.sort!{|r, u| (u.user.organization.present? && r.user.organization.present?) ? u.trial.trial_id <=> r.trial.trial_id : '' <=> ''}
    elsif sort_column == "last_sign_in_at"      
      all_roles = sort_direction == 'asc' ? all_roles.sort_by!{|r| r.user.last_sign_in_at.present? ? r.user.last_sign_in_at : ''} : all_roles.sort!{|r, u| (u.user.last_sign_in_at.present? && r.user.last_sign_in_at.present?) ? u.user.last_sign_in_at.site_id <=> r.user.last_sign_in_at.site_id : '' <=> ''}
    end
    all_roles = all_roles.paginate(page: page, :per_page => per_page)
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[email organization last_sign_in_at]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end