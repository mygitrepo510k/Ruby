class TrialBinderDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view

  def initialize(view,trial)
    @view   = view
    @trial = trial
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: binders.count,
      iTotalDisplayRecords: binders.total_entries,
      aaData: data.compact
    }
  end

private
  def data
    binders.map do |binder|
      [
        link_to(binder.binder_id, "/dashboard/trials/#{@trial.id}/trial_binders/#{binder.id}/edit", remote: true, class:'edit_binder-item'),
        binder.documents.count,        
        binder.sites.count,
        binder.completed_binders.count,
        binder.avg_time,
        "<div class='btn-group btn-toggle' data-update-url='/dashboard/update_status'>
            <button class='btn btn-xs #{binder.status==1 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{binder.id.to_s}' data-status='1' data-type='#{binder.class.name}'>Yes</button>
            <button class='btn btn-xs #{binder.status==0 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{binder.id.to_s}' data-status='0' data-type='#{binder.class.name}'>No</button>
          </div>".html_safe,
        "row_#{binder.id.to_s}"
      ]  
    end
  end

  def binders
    @binders ||= fetch_binders
  end

  def fetch_binders
    binders = @trial.trial_binders
    
    if params[:show_option].strip == "Include disabled"
      binders = binders.not_in(status:0)
    end
    
    if params[:sSearch].present?
      binders = binders.where({:binder_id=>/^.*#{params[:sSearch]}.*$/i})
    end
    binders = binders.order("#{sort_column} #{sort_direction}").paginate(page: page, :per_page => per_page)
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[binder_id]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end
