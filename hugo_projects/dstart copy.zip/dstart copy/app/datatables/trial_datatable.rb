class TrialDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view

  def initialize(view, user, vpd)
    @view = view
    @user = user
    @vpd = vpd
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: trials.count,
      iTotalDisplayRecords: trials.total_entries,
      aaData: data.compact
    }
  end

private

  def data
    if @user.super_admin? && @vpd.blank?
      trials.map do |trial|
        [
          link_to(trial.trial_id.truncate(12), "/dashboard/trials/#{trial.id.to_s}/sites", title:trial.trial_id),
          link_to(trial.title.truncate(44), "/dashboard/trials/#{trial.id.to_s}/sites", title:trial.title),
          link_to(trial.vpd.name.truncate(12), "#", title:trial.vpd.name),
          link_to(trial.sponsor_name.truncate(10), "#", title:trial.sponsor_name),
          trial.role_name_by_user(@user),
          "<div class='btn-group btn-toggle' data-update-url='/dashboard/update_status'>
            <button class='btn btn-xs #{trial.status==1 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{trial.id.to_s}' data-status='1' data-type='#{trial.class.name}'>Yes</button>
            <button class='btn btn-xs #{trial.status==0 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{trial.id.to_s}' data-status='0' data-type='#{trial.class.name}'>No</button>
          </div>".html_safe,
          "row_#{trial.id.to_s}"
        ]
      end
    elsif @user.super_admin? && @vpd.present?
      trials.map do |trial|
        [ 
          link_to(trial.trial_id.truncate(12), "/dashboard/vpds/#{@vpd.id.to_s}/trials/sites?id=#{trial.id.to_s}", title:trial.trial_id),
          link_to(trial.title.truncate(44), "/dashboard/vpds/#{@vpd.id.to_s}/trials/sites?id=#{trial.id.to_s}", title:trial.title),
          link_to(trial.sponsor_name.truncate(10), "#", title:trial.sponsor_name),
          trial.role_name_by_user(@user),
          "<div class='btn-group btn-toggle' data-update-url='/dashboard/update_status'>
            <button class='btn btn-xs #{trial.status==1 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{trial.id.to_s}' data-status='1' data-type='#{trial.class.name}'>Yes</button>
            <button class='btn btn-xs #{trial.status==0 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{trial.id.to_s}' data-status='0' data-type='#{trial.class.name}'>No</button>
          </div>".html_safe,
          "row_#{trial.id.to_s}"
        ]
      end
    elsif @user.trial_level_user?
      trials.map do |trial|
        [
          link_to(trial.trial_id.truncate(12), "/dashboard/trials/#{trial.id.to_s}/sites", title:trial.trial_id),
          link_to(trial.title.truncate(55), "/dashboard/trials/#{trial.id.to_s}/sites", title:trial.title),
          link_to(trial.sponsor_name.truncate(10), "#", title:trial.sponsor_name),
          trial.role_name_by_user(@user),
          "<div class='btn-group btn-toggle' data-update-url='/dashboard/update_status'>
            <button class='btn btn-xs #{trial.status==1 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{trial.id.to_s}' data-status='1' data-type='#{trial.class.name}'>Yes</button>
            <button class='btn btn-xs #{trial.status==0 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{trial.id.to_s}' data-status='0' data-type='#{trial.class.name}'>No</button>
          </div>".html_safe,
          "row_#{trial.id.to_s}"
        ]
      end
    else
      trials.map do |trial|
        user_sites = @user.sites_of_trial(trial)
        if user_sites.count == 1
          [
            link_to(trial.trial_id.truncate(14), "/dashboard/sites/#{user_sites.first.id.to_s}/users", title:trial.trial_id),
            link_to(trial.title.truncate(55), "/dashboard/sites/#{user_sites.first.id.to_s}/users", title:trial.title),
            link_to(trial.sponsor_name.truncate(10), "#", title:trial.sponsor_name),
            trial.role_name_by_user(@user),
            trial.status==1 ? "YES" : "NO",
            "row_#{trial.id.to_s}"
          ]
        elsif user_sites.count > 1
          [
            link_to(trial.trial_id.truncate(14), "/dashboard/trials/#{trial.id.to_s}/sites", title:trial.trial_id),
            link_to(trial.title.truncate(55), "/dashboard/trials/#{trial.id.to_s}/sites", title:trial.title),
            link_to(trial.sponsor_name.truncate(10), "#", title:trial.sponsor_name),
            trial.role_name_by_user(@user),
            trial.status==1 ? "YES" : "NO",
            "row_#{trial.id.to_s}"
          ]
        end
      end
    end
  end

  def trials
    @trials ||= fetch_trials
  end

  def fetch_trials
    if @vpd.present?
      trials = @vpd.trials
    else
      trials = @user.all_trials
    end

    if params[:show_option].strip == "Include disabled"
      trials = trials.activated_trials
    end

    if params[:sSearch].present?
      trials = trials.any_of({:trial_id=>/^.*#{params[:sSearch]}.*$/i}, {:title=>/^.*#{params[:sSearch]}.*$/i})
    end
    trials = trials.order("#{sort_column} #{sort_direction}").paginate(page: page, :per_page => per_page)        
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[trial_id title]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end