class UserDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view

  def initialize(view, user)
    @view = view
    @user = user
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: users.count,
      iTotalDisplayRecords: users.total_entries,
      aaData: data.compact
    }
  end

  private

  def data
    users.map do |user|
      [          
        link_to(user.email, "#profile", data:{url: "/dashboard/user_info?id=#{user.id.to_s}&type=ajax"}, class:"event-buttn") +"<br/>".html_safe+ user.name,
        user.organization,
        user.last_login,
        link_to(user.status_label, "/dashboard/edit_user?id=#{user.id.to_s}", remote: true, class: :"users"),
        "row_"+user.id.to_s
      ]
    end
  end

  def users
    @users ||= fetch_users
  end

  def fetch_users
    all_users = User.all.not_in(id: @user.id)
    
    if params[:show_option].strip == "Include disabled"
      all_users = all_users.activated_users
    end

    if params[:sSearch].present?
      all_users = all_users.any_of({:email=>/^.*#{params[:sSearch]}.*$/i}, {:name=>/^.*#{params[:sSearch]}.*$/i}, {:organization=>/^.*#{params[:sSearch]}.*$/i})
    end
    all_users = all_users.all.order("#{sort_column} #{sort_direction}").paginate(page: page, :per_page => per_page)
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[email organization last_sign_in_at status]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end