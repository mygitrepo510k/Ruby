class VpdDocumentDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view

  def initialize(view, vpd)
    @view   = view
    @vpd   = vpd
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: documents.count,
      iTotalDisplayRecords: documents.total_entries,
      aaData: data.compact
    }
  end

private
  def data

    documents.map do |document|
      [
        link_to(document.type_name, "/dashboard/vpds/#{@vpd.id}/vpd_documents/#{document.id}/edit"),
        link_to(document.name, "/dashboard/vpds/#{@vpd.id}/vpd_documents/#{document.id}/edit"),
        document.sites.count,
        document.completed_docs.count,
        document.avg_time,
        "<div class='btn-group btn-toggle' data-update-url='/dashboard/update_status'>
            <button class='btn btn-xs #{document.status==1 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{document.id.to_s}' data-status='1' data-type='#{document.class.name}'>Yes</button>
            <button class='btn btn-xs #{document.status==0 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{document.id.to_s}' data-status='0' data-type='#{document.class.name}'>No</button>
          </div>".html_safe,        
        "row_#{document.id.to_s}"
      ]
    end  
  end

  def documents
    @documents ||= fetch_documents
  end

  def fetch_documents    
    documents = @vpd.vpd_documents
    
    if params[:show_option].strip == "Include disabled"
      documents = documents.not_in(status:0)
    end
    
    if params[:sSearch].present?
      documents = documents.any_of({:document_id=>/^.*#{params[:sSearch]}.*$/i},{:name=>/^.*#{params[:sSearch]}.*$/i})
    end
    documents = documents.order("#{sort_column} #{sort_direction}").paginate(page: page, :per_page => per_page)
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[document_id name due_days]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end
