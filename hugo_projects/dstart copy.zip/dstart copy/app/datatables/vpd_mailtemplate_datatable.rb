class VpdMailtemplateDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view

  def initialize(view, vpd)
    @view   = view
    @vpd    = vpd
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: mailtemplates.count,
      iTotalDisplayRecords: mailtemplates.total_entries,
      aaData: data.compact
    }
  end

private
  def data
    mailtemplates.map do |mailtemplate|
      [        
        link_to(mailtemplate.name.truncate(25), "/dashboard/vpds/#{@vpd.id.to_s}/mail_templates/#{mailtemplate.id.to_s}/edit", remote: true, title: mailtemplate.name),
        mailtemplate.subject,
        "<div class='btn-group btn-toggle' data-update-url='/dashboard/update_status'>
            <button class='btn btn-xs #{mailtemplate.status==1 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{mailtemplate.id.to_s}' data-status='1' data-type='#{mailtemplate.class.name}'>Yes</button>
            <button class='btn btn-xs #{mailtemplate.status==0 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{mailtemplate.id.to_s}' data-status='0' data-type='#{mailtemplate.class.name}'>No</button>
          </div>".html_safe,        
        "row_#{mailtemplate.id.to_s}"
      ]
    end  
  end

  def mailtemplates
    @mailtemplates ||= fetch_mailtemplates
  end

  def fetch_mailtemplates    
    mailtemplates = @vpd.vpd_mail_templates
    
    if params[:show_option].strip == "Include disabled"
      mailtemplates = mailtemplates.activated_mail_templates
    end
    
    if params[:sSearch].present?
      mailtemplates = mailtemplates.any_of({:mailtemplate_id=>/^.*#{params[:sSearch]}.*$/i},{:name=>/^.*#{params[:sSearch]}.*$/i})
    end
    mailtemplates = mailtemplates.order("#{sort_column} #{sort_direction}").paginate(page: page, :per_page => per_page)
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[name subject]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end