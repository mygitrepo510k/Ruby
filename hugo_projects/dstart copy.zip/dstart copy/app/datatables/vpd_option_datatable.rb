class VpdOptionDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view

  def initialize(view, vpd, option)
    @view     = view    
    @@vpd     = vpd
    @@option  = option
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: option_fields.count,
      iTotalDisplayRecords: option_fields.total_entries,
      aaData: data.compact
    }
  end

  private

  def data
    option_fields.map do |option|
      [
        # link_to(option.option, "javascript://", data:{id:option.id.to_s, status:option.status, option:option.option, option_type:option.option_type, target: "#edit_option_modal", toggle: :modal}, class: 'edit-option-item'),
        option.option,
        option.populate_name,
        "<div class='btn-group btn-toggle' data-update-url='/dashboard/vpds/#{@@vpd.id.to_s}/change_option_status'>
          <button class='btn btn-xs #{option.status==1 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{option.id.to_s}' data-status='1'>Yes</button>
          <button class='btn btn-xs #{option.status==0 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{option.id.to_s}' data-status='0'>No</button>
        </div>".html_safe,
        "row_"+option.id.to_s
      ]
    end  
  end

  def option_fields
    @options ||= fetch_options
  end

  def fetch_options
    if @@option == 0
      all_options = @@vpd.trial_fields
    else
      all_options = @@vpd.site_fields
    end
    
    if params[:show_option].strip == "Include disabled"
      all_options = all_options.not_in(status:0)
    end

    if params[:sSearch].present?
      all_options = all_options.any_of({:option=>/^.*#{params[:sSearch]}.*$/i})
    end
    all_options = all_options.all.order("#{sort_column} #{sort_direction}").paginate(page: page, :per_page => per_page)
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[option]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end
