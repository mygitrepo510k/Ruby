class VpdUserDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view

  def initialize(view, user, vpd)
    @view   = view
    @user   = user
    @vpd    = vpd
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: users.count,
      iTotalDisplayRecords: users.total_entries,
      aaData: data.compact
    }
  end

  private

  def data
    users.map do |role|
      [
        role.user.email + "<br/>".html_safe + role.user.name,
        role.trial.present? ? link_to(role.trial.trial_id, "/dashboard/trials/#{role.trial.id.to_s}") : "",
        role.site.present? ? link_to(role.site.site_id, "/dashboard/sites/#{role.site.id.to_s}/documents") : "",
        role.role_label,
        "<div class='btn-group btn-toggle' data-update-url='/dashboard/update_status'>
          <button class='btn btn-xs #{role.status==1 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{role.id.to_s}' data-status='1' data-type='#{role.class.name}'>Yes</button>
          <button class='btn btn-xs #{role.status==0 ? 'btn-warning active' : 'btn-default'}' style='padding:1px 5px' data-id='#{role.id.to_s}' data-status='0' data-type='#{role.class.name}'>No</button>
        </div>".html_safe,        
        "row_"+role.id.to_s
      ]
    end    
  end

  def users
    @users ||= fetch_users
  end

  def fetch_users
    require 'will_paginate/array'
    role_ids = []
    if params[:show_option].strip == "Include disabled"
      status = 1
    else
      status = 0
    end
    @vpd.trials.each do |trial|
      trial_roles  = status == 0 ? trial.roles : trial.roles.activated_roles
      trial_roles.each do |role|
        role_ids << role.id.to_s
      end
      trial.sites.each do |site|
        site_roles = status == 0 ? site.roles : site.roles.activated_roles
        site_roles.each do |role|
          role_ids << role.id.to_s
        end
      end
    end

    all_users = Role.in(id:role_ids.flatten)

    if params[:sSearch].present?
      # all_users = all_users.any_of({:email=>/^.*#{params[:sSearch]}.*$/i}, {:name=>/^.*#{params[:sSearch]}.*$/i})
      all_users = all_users.select{|r| r.user.email =~ /#{params[:sSearch]}/}
    end

    if sort_column == "email"
      all_users = sort_direction == 'asc' ? all_users.sort_by!{|r| r.user.email} : all_users.sort!{|r, u| u.user.email <=> r.user.email}
    elsif sort_column == "trial_id"      
      all_users = sort_direction == 'asc' ? all_users.sort_by!{|r| r.trial.present? ? r.trial.trial_id : ''} : all_users.sort!{|r, u| (u.trial.present? and r.trial.present?) ? u.trial.trial_id <=> r.trial.trial_id : '' <=> ''}
    elsif sort_column == "site_id"      
      all_users = sort_direction == 'asc' ? all_users.sort_by!{|r| r.site.present? ? r.site.site_id : ''} : all_users.sort!{|r, u| (u.site.present? and r.site.present?) ? u.site.site_id <=> r.site.site_id : '' <=> ''}
    end
    all_users = all_users.paginate(page: page, :per_page => per_page)
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[email trial_id site_id]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end
