class UserMailer < ActionMailer::Base
  include Devise::Mailers::Helpers

  default from: Dstart::Application::CONSTS[:contact_email]

  # Subject can be set in your I18n file at config/locales/en.yml
  # with the following lookup:
  #
  #   en.user_mailer.expire_email.subject
  #
  def expire_email(user)
    mail(:to => user.email, :subject => "Subscription Cancelled")
  end
  
  def confirmation_email(user)
    mail(:to => user.email, :subject => "Created new account")
  end

  def contact_email(name, email, text)
    @name         = name
    @email        = email
    @text         = text
    mail(to: :from, :subject => "Contact")
  end

  # Send email when invited in a vpd
  def invited_vpd_admin(user, vpd)
    @user         = user
    @vpd          = vpd
    @template     = @vpd.mailtemplate(VpdMailTemplate::MAIL_TEMPLATES[:invited_vpd_admin])
    if @template.present?
      @subject    = @template.subject
      @body       = @template.body
    else
      @subject    = "You are invited to #{@vpd.name} as a vpd admin"
    end
    mail(:to=> @user.email, :subject => @subject)
  end
  
  # Send email when invited in a trial
  def invited_trial_admin(user, trial)
    @user         = user
    @trial        = trial
    @vpd          = trial.vpd

    @template     = @vpd.mailtemplate(VpdMailTemplate::MAIL_TEMPLATES[:invited_trial_admin])
    if @template.present?
      @subject    = @template.subject
      @body       = @template.body
    else
      @subject    = "You are invited to #{@trial.trial_id} as a trial admin"
    end
    mail(:to=> @user.email, :subject => @subject)
  end
  
  # Send email when invited in a site
  def invited_site_user(user, site)
    @user         = user
    @site         = site
    @vpd          = @site.trial.vpd

    @template     = @vpd.mailtemplate(VpdMailTemplate::MAIL_TEMPLATES[:invited_site_user])
    if @template.present?
      @subject    = @template.subject
      @body       = @template.body
    else
      @subject    = "You are invited to #{@site.site_id} as a site user"
    end

    mail(:to=> @user.email, :subject => @subject)
  end

  # Send email when changed role in a trial
  def changed_trial_role(user, trial, origin_role, new_role)
    @user         = user
    @trial        = trial
    @origin_role  = origin_role 
    @new_role     = new_role 

    @vpd          = @trial.vpd

    @template     = @vpd.mailtemplate(VpdMailTemplate::MAIL_TEMPLATES[:changed_trial_role])
    if @template.present?
      @subject    = @template.subject
      @body       = @template.body
    else
      @subject  = "Changed your role on #{trial.trial_id} to #{new_role.role_label}"      
    end

    mail(:to=> @user.email, :subject => @subject)
  end

  # Send email when changed role in a site
  def changed_site_role(user, site, origin_role, new_role)
    @user         = user
    @site         = site
    @origin_role  = origin_role 
    @new_role     = new_role 
    @vpd          = @site.trial.vpd

    @template     = @vpd.mailtemplate(VpdMailTemplate::MAIL_TEMPLATES[:changed_site_role])
    if @template.present?
      @subject    = @template.subject
      @body       = @template.body
    else
      @subject  = "Changed your role on #{site.name} to #{new_role.role_label}"      
    end    
    mail(:to=> @user.email, :subject => @subject)
  end

  def changed_status(user,type)
    @user     = user
    @type     = type == '1' ? 'Active' : 'Disable'
    @subject  = "You account status has been changed to #{@type}"
    mail(:to=> @user.email, :subject => @subject)
  end
  # Send email when document status was changed via heroku scheduler
  # 
  # Can't use vpd document template
  def document_notification(user, documents)
    @user         = user
    @documents    = documents
    @vpd          = @site.trial.vpd
    
    @template     = @vpd.mailtemplate(VpdMailTemplate::MAIL_TEMPLATES[:document_notification])
    
    if @template.present?
      @subject    = @template.subject
      @body       = @template.body
    else
      @subject    = "Document notification"
    end    

    
    mail(:to=> @user.email, :subject => @subject)
  end

  # Send email when new document added to site
  def add_new_document_notification(user, document)
    @user         = user
    @document     = document
    @vpd          = @document.vpd 
    @template     = @vpd.mailtemplate(VpdMailTemplate::MAIL_TEMPLATES[:add_new_document_notification])
    if @template.present?
      @subject    = @template.subject
      @body       = @template.body
    else      
      @subject    = "Added new document on your site '#{@document.binder.site.site_id}'"
    end
    mail(:to=> @user.email, :subject => @subject)
  end

  # Send email when document status ( unlocked to locked )  
  def changed_document_status(user,document)
    @user         = user
    @document     = document
    @vpd          = @document.vpd 

    @template     = @vpd.mailtemplate(VpdMailTemplate::MAIL_TEMPLATES[:changed_document_status])
    if @template.present?
      @subject    = @template.subject
      @body       = @template.body
    else
      @subject    = "Document status was changed"
    end
    mail(:to=> @user.email, :subject => @subject)
  end

  # Send email when new file attached on document
  def attached_new_file(by_user, user,document)
    @by_user      = by_user
    @user         = user
    @document     = document
    @vpd          = @document.vpd

    @template     = @vpd.mailtemplate(VpdMailTemplate::MAIL_TEMPLATES[:attached_new_file])
    if @template.present?
      @subject    = @template.subject
      @body       = @template.body
    else
      @subject    = "Attached new file to #{@document.name} by #{by_user.name}"
    end
    mail(:to=> @user.email, :subject => @subject)
  end

  # Send email when document was signed
  def signed_document(signed_user, user, document)
    @signed_user  = signed_user
    @user         = user
    @document     = document
    @vpd          = @document.vpd

    @template     = @vpd.mailtemplate(VpdMailTemplate::MAIL_TEMPLATES[:signed_document])
    if @template.present?
      @subject    = @template.subject
      @body       = @template.body
    else
      @subject    = "#{@document.name} is signed by #{signed_user.name}"
    end

    mail(:to=> @user.email, :subject => @subject)
  end

  # Send emmail when document is locked
  def locked_document(locked_user, user, document)
    @locked_user  = locked_user
    @user         = user
    @document     = document
    @vpd          = @document.vpd

    @template     = @vpd.mailtemplate(VpdMailTemplate::MAIL_TEMPLATES[:signed_document])
    if @template.present?
      @subject    = @template.subject
      @body       = @template.body
    else
      @subject    = "#{@document.name} is locked by #{locked_user.name}"
    end

    mail(:to=> @user.email, :subject => @subject)
  end
end