class Account
  include Mongoid::Document
  include Mongoid::Timestamps
  
  field :base_rate,               type: Float, default: 1
  field :per_complete_site,       type: Float, default: 1
  field :per_incomplete_site,     type: Float, default: 1

  field :accounting_date,          type: Date
  field :complete_sites,          type: Float
  field :incomplete_sites,        type: Float
  field :total,                   type: Float

  belongs_to :vpd

  def self.add_accounting
  end
end