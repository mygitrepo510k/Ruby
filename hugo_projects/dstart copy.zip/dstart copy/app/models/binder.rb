# It's for site binder
class Binder
  include Mongoid::Document
  include Mongoid::Timestamps
  
  field :binder_id,         type: String,   default: ""
  field :status,            type: Integer,  default: 1

  belongs_to :vpd
  belongs_to :trial
  belongs_to :site
  belongs_to :vpd_binder
  belongs_to :trial_binder

  has_many :documents,      dependent: :destroy

  validates_presence_of :binder_id, :vpd_id, :trial_id, :site_id
  validates_uniqueness_of :binder_id, scope: :site_id, :case_sensitive => false
  
  def completed?
    !!completed_day
  end

  def completed_day
    days = []
    documents.not_in(state:0).each do |doc|
      return nil unless doc.is_completed
      days << doc.completed_day
    end
    days.sort.last
  end

  def state_name
    doc_state       = []
    binder_state    = 'progress'
    documents.not_in(state:0).each do |doc|
      if doc.is_expired
        doc_state << "is_expired"
      elsif doc.is_completed
        doc_state << "is_completed"
      elsif doc.is_over_due
        doc_state << "is_over_due"
      else
        doc_state << "is_negotiation"
      end
    end
  
    doc_state = doc_state.join(",")
    if doc_state =~ /is_expired/
      binder_state = "expired"
    elsif doc_state =~ /is_over_due/
      binder_state = "overdue"
    elsif doc_state =~ /is_negotiation/
      binder_state = "progress"
    else #if doc_state =~ /is_completed/
      binder_state = "complete"    
    end
  
    return binder_state
  end
  
end
