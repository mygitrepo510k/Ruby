class Country
  include Mongoid::Document
  include Mongoid::Timestamps

  field :name,    type: String, default: '' # country name
  field :code,    type: String              # country code
  field :status,  type: Integer, default: 1 # active/disable

  validates :code, presence: true
  validates :name, presence: true, uniqueness: true

  has_many :vpd_countries
  has_many :sites

  scope :activated_countries, -> {where(status: 1)}

  # Public: Get all trials of this country
  # 
  # Returns trials
  def trials
    trial_ids = sites.activated_sites.map(&:trial_id)
    Trial.in(id: trial_ids).activated_trials
  end

  # Public: Get all completed sites of this country
  # 
  # Returns sites
  def completed_sites
    site_ids = []
    sites.activated_sites.each do |site|
      site_ids << site.id.to_s if site.completed?
    end
    Site.in(id: site_ids)
  end

  # Public: Get all completed sites of this country
  # 
  # Returns sites
  def cycle_time
    completed_site_days = []
    sites.activated_sites.each do |site|
      completed_site_days << site.completed_day if site.completed?      
    end
    completed_site_days.count > 0  ?  (completed_site_days.sum.to_f / completed_site_days.count).round(1).to_s + " d"  :  "N/A"
  end
end