# It's for site document
class Document
  include Mongoid::Document
  include Mongoid::Timestamps
  
  DOCUMENT_STATUS = ["PROGRESS", "READY", "SIGNED"] 
  POPULATE_LIST = %w[__TRIAL_NAME__ __TRIAL_ID__ __TRIAL_NCT__ __SPONSOR_NAME__ __SITE_NAME__ __SITE_ADDRESS__ __SITE_CITY__ __SITE_STATE__ __SITE_COUNTRY__ __SITE_ZIPCODE__ __SITE_ZIPCODE__]

  field :name,                type: String
  field :content,             type: String
  
  field :due_date,            type: Date
  field :due_days,            type: Integer
  
  field :document_type,       type: Integer, default: 0
  field :play_book,           type: String
  field :document_mode,       type: Integer
 
  field :status,              type: Integer, default: 0
  field :state,               type: Integer, default: 1
  
  field :sign_mode,           type: Boolean, default: false
  field :locked_mode,         type: Boolean, default: false

  field :verified_date,       type: Date                            # when first document is verified date
  field :uploaded_document,   type: Boolean, default: false

  field :sent_email,          type: Boolean, default: false         #for using for cronjob

  field :trial_signed_at,     type: DateTime
  field :site_signed_at,      type: DateTime
  
  field :trial_signature,     type: String                          # for trial user signature iamge data
  field :site_signature,      type: String                          # for site user signature iamge data
  
  field :trial_sign_user_name,  type: String                        # for trial 
  field :site_sign_user_name,  type: String                         # for site user signature iamge data

  belongs_to :trial_signed_user, class_name: "User"                 
  belongs_to :site_signed_user, class_name: "User"

  belongs_to :binder
  belongs_to :trial_document
  
  belongs_to :vpd

  has_many :document_files, dependent: :destroy

  validates_uniqueness_of :trial_document_id, scope: :binder_id

  scope :completed_documents, -> {not_in(verified_date:nil)}
  
  after_create :set_vpd
  
  def site_signed_user_name
    if site_sign_user_name.present?
      site_sign_user_name
    else
      ""
    end    
  end

  def trial_signed_user_name
    if trial_sign_user_name.present?
      trial_sign_user_name
    else
      ""
    end    
  end

  def site
    binder.site
  end

  def type_name
    VpdDocument::DOCUMENT_TYPES[document_type]
  end

  def is_signed
    site_signature.present? && trial_signature.present?
  end
  
  def is_completed
    document_files.where(verified:true).count > 0 and verified_date.present?
  end

  def completed_day
    return nil if (!is_completed or verified_date.blank?)
    created_date    = created_at.to_date    
    (verified_date - created_date).to_i
  end
  
  def is_over_due
    if is_completed or due_date.nil?
      false
    else
      Time.now > due_date
    end
  end  
  
  def expired_date 
    if is_completed
      last_doc_file = document_files.where(verified:true).order("expire_date DESC").first
      last_doc_file.expire_date.present? ? last_doc_file.expire_date.strftime("%d %b %Y") : ""
    else
      ""
    end
  end

  def is_expired    
    if is_completed
      last_doc_file = document_files.where(verified:true).order("expire_date DESC").first
      last_doc_file.expire_date.present? ? Time.now.to_date > last_doc_file.expire_date : false      
    else
      false
    end
  end

  def is_negotiation
    if is_completed or is_expired or is_over_due or due_date.nil?
      false
    else
      Time.now < due_date
    end
  end

  def populate
    site = binder.site
    temp_content = content    

    vpd.options.available_options.each do |option|
      if option.option_type == 0        # case in trial
        temp_content = temp_content.gsub(option.populate_name,trial_document.trial.extra_field_value(option.option)) unless trial_document.trial.extra_field_value(option.option).nil?
      elsif option.option_type == 1     # case in site
        temp_content = temp_content.gsub(option.populate_name,binder.site.extra_field_value(option.option)) unless binder.site.extra_field_value(option.option).nil?
      end      
    end

    Document::POPULATE_LIST.each_with_index do |item, index|
      case index
      when 0
        temp_content = temp_content.gsub(item,trial_document.trial.title) unless trial_document.trial.title.nil?
      when 1
        temp_content = temp_content.gsub(item,trial_document.trial.trial_id) unless trial_document.trial.trial_id.nil?
      when 2
        temp_content = temp_content.gsub(item,trial_document.trial.nct) unless trial_document.trial.nct.nil?
      when 3
        temp_content = temp_content.gsub(item,trial_document.trial.sponsor_name)  unless trial_document.trial.sponsor_name.nil?
      when 4
        temp_content = temp_content.gsub(item,binder.site.name) unless binder.site.name.nil?
      when 5
        temp_content = temp_content.gsub(item,binder.site.address) unless binder.site.address.nil?
      when 6
        temp_content = temp_content.gsub(item,binder.site.city) unless binder.site.city.nil?
      when 7
        temp_content = temp_content.gsub(item,binder.site.state) unless binder.site.state.nil?
      when 8
        temp_content = temp_content.gsub(item,binder.site.country_name) unless binder.site.country_name.nil?
      when 9
        temp_content = temp_content.gsub(item,binder.site.zip_code) unless binder.site.zip_code.nil?
      end
    end
    temp_content
  end

  def related_users
    trial = trial_document.trial
    trial.users
  end

  def status_name
    if is_expired
      "expired"
    elsif is_completed
      "completed"
    elsif is_over_due
      "overdue"
    elsif locked_mode
      "countersign"
    elsif sign_mode
      "signature"
    else
      "progress"
    end
  end

  def self.check_document_status
    cur_time    = Time.now
    User.all.each do |user|
      next if user.vpd_level_user?
      documents = user.documents
      notif_docs = []
      documents.each do |doc|
        next if doc.sent_email
        if doc.is_expired
          notif_docs << doc
          doc.update_attributes(sent_email:true)
        elsif doc.is_over_due
          notif_docs << doc
          doc.update_attributes(sent_email:true)
        end
      end
      UserMailer.document_notification(user, notif_docs).deliver if notif_docs.size > 0
    end
  end

  private
  def set_vpd
    self.vpd = trial_document.trial.vpd
    save
  end
end