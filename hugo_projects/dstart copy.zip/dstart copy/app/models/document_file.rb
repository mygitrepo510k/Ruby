class DocumentFile
  include Mongoid::Document
  include Mongoid::Timestamps  
  include Mongoid::Paperclip
  ## for carrierwave uploarder  
  # mount_uploader :file, PdfFileUploader  
  # field :file,          type: String

  # upload using paperclip
  has_mongoid_attached_file :file,
      :path           => ':attachment/:id/:style.:extension',
      :storage        => :s3,
      :url            => 's3-us-west-2.amazonaws.com',
      :s3_host_alias  => 'something.cloudfront.net'

  validates_attachment :file, content_type: { content_type: [ "application/pdf",
                                                              "application/msword",
                                                              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                                              "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ] }

  field :verified,      type: Boolean, default: false
  field :expire_date,   type: Date

  belongs_to :verified_user, class_name: "User"

  belongs_to :document
  belongs_to :trial_document
  belongs_to :vpd_document
  
  validates_presence_of :file
   
  def verified_user_name
    verified_user.present? ? verified_user.name : ""
  end
  
  def name
    file_file_name
    # url.split("/")[7].split("?").first
    # File.basename(file.url).split('?').first if file.present?
    # file.file.filename if file.present?
  end
  
  def url
    file.url
  end

  def parent
    if document.present?
      document
    elsif trial_document.present?
      trial_document
    elsif vpd_document.present?
      vpd_document
    end
  end
  
end