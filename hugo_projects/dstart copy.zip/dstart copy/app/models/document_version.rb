class DocumentVersion
  include Mongoid::Document
  include Mongoid::Timestamps
    
  field       :content,                 type: String, default: ""
  field       :document_version,        type: String, default: "1.0"
  
  belongs_to :vpd_document
  belongs_to :trial_document

  validates_presence_of :document_version

  validate :exist_version_on_trial_or_vpd, :on => :create

  # default_scope -> {where(status: 1)}

  def exist_version_on_trial_or_vpd
    if trial_document.present?
      if DocumentVersion.where(trial_document:trial_document, document_version:document_version).first.present?
        errors.add("'#{document_version}'", 'has been added to this trial_document')
      end
    elsif vpd_document.present?
      if DocumentVersion.where(vpd_document:vpd_document, document_version:document_version).first.present?
        errors.add("'#{document_version}'", 'has been added to this vpd_document')
      end
    end    
  end

end