# Table name :options
# option_type = 0 is trial extra fields, option_type = 1 is site extra fields

class Option
  include Mongoid::Document
  include Mongoid::Timestamps

  field :option,              type: String
  field :value,               type: String
  field :order,               type: Integer
  field :option_type,         type: Integer 
  field :status,              type: Integer, default: 1  
  
  scope :trial_fields,        -> {where(option_type:0)}
  scope :site_fields,         -> {where(option_type:1)}
  
  scope :available_options,   -> {where(status:1)}
  
  belongs_to :vpd

  validates_presence_of :option
  validates_uniqueness_of :option, scope: [:vpd_id, :option_type]

  def status_name
    status == 1 ? "Active" : "Disabled"
  end

  def populate_name
    option_type == 0 ? "__TRIAL_#{option.upcase}__" : "__SITE_#{option.upcase}__"
  end
  
  def option=(val)
    self[:option] = val.downcase
  end
end