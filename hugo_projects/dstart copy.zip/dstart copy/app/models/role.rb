class Role
  include Mongoid::Document
  include Mongoid::Timestamps

  ROLES = {super_admin: 1, vpd_admin: 2, trial_admin: 3, trial_readonly: 5, trial_associate: 8, site_admin: 13, site_readonly: 21, site_user: 34}

  field :role,    type: Integer             # role - user's position in trial or site
  field :status,  type: Integer, default: 1 # active/disable

  belongs_to :rolify, polymorphic: true
  belongs_to :user
  # belongs_to :trial
  # belongs_to :site

  validates_presence_of :role, :user
  validates_uniqueness_of :user, scope: :rolify
  
  scope :activated_roles, -> {where(status: 1)}
  
  # Public: Get trial of this role
  # 
  # Returns trial
  def trial
    if rolify.class == Trial
      return rolify
    else
      return rolify.trial
    end
  end

  # Public: Get site of this role
  # 
  # Returns site
  def site
    if rolify.class == Site
      return rolify
    else
      nil
    end
  end

  # Public: Get role name string of this role
  # 
  # Returns role name string
  def role_label
    case role
    when ROLES[:trial_admin] 
      "TRADM"
    when ROLES[:trial_readonly]
      "TRADR"
    when ROLES[:trial_associate]
      "TCADM"
    when ROLES[:site_admin]
      "STADM"
    when ROLES[:site_readonly]
      "STADR"
    when ROLES[:site_user]
      "STU"
    end
  end

  # Public: Get user email string of this role
  # 
  # Returns email string
  def email
    user.email
  end
end