class Site
  include Mongoid::Document
  include Mongoid::Timestamps

  SITE_STATUS = {}

  field :name,          type: String, default: '' # site name
  field :site_id,       type: String, default: '' # site Id

  field :city,          type: String              # city
  field :state,         type: String              # state
  field :state_code,    type: String              # state code
  field :address,       type: String              # address
  field :zip_code,      type: String              # zip code

  field :country_name,  type: String              # country name 
  field :status,        type: Integer, default: 1 # active/disable

  field :extra_fields,  type: Hash                # for vpd's extra fields

  belongs_to :country
  belongs_to :vpd_country

  belongs_to :trial
  belongs_to :trial_binder

  has_many :roles, as: :rolify, dependent: :destroy

  has_one :binder,                dependent: :destroy
  
  scope :activated_sites, -> {where(status: 1)}

  validates_presence_of :name, :site_id, :trial_id, :country_id
  validates_uniqueness_of :site_id, scope: :trial_id, case_sensitive: false

  # Public: Get all activated users of this site
  # 
  # Returns users
  def users
    user_ids = roles.activated_roles.map(&:user_id)
    User.in(id: user_ids)
  end

  # Public: Check if the given user is real trial associate in this site
  # 
  # Returns boolean value
  def trial_associate?(user)
    roles.activated_roles.where(user: user, role: Role::ROLES[:trial_associate]).first.present?
  end
  
  # Public: Check if the given user is real site admin in this site
  # 
  # Returns boolean value
  def site_admin?(user)
    roles.activated_roles.where(user: user, role: Role::ROLES[:site_admin]).first.present?
  end

  # Public: Check if the given user is real site user in this site
  # 
  # Returns boolean value
  def site_user?(user)
    roles.activated_roles.where(user: user, role: Role::ROLES[:site_user]).first.present?
  end

  # Public: Check if the given user is real site readonly user in this site
  # 
  # Returns boolean value
  def site_readonly?(user)
    roles.activated_roles.where(user: user, role: Role::ROLES[:site_readonly]).first.present?
  end
  
  # Public: Check user status in site for SA, SU, SAR
  # 
  # Returns Boolean
  def site_only_user?(user)
    role = roles.activated_roles.where(user: user).first
    if role.present?
      role.role >= Role::ROLES[:site_admin]
    else
      false
    end
  end

  # Public: Set site Id as CAPs
  def site_id=(val)
    self[:site_id] = val.upcase
  end

  ###################### Actions for dstart project ####################
  # 
  #
  ######################################################################

  # Public: Check if the site is completed or not
  # 
  # Returns boolean string
  def completed?
    binder.completed? if binder.present?
  end
  
  # Public: Check if the site is completed or not
  # 
  # Returns boolean string
  def completed_day
    binder.completed_day
  end

  # Public: Get documents included in site
  # 
  # Returns documents object
  def documents
    binder.present? ? binder.documents : []
  end

  # Public: Get completed documents
  # 
  # Returns documents object
  def completed_documents
    doc_ids = []
    documents.each do |doc|
      doc_ids << doc.id.to_s if doc.is_completed
    end
    Document.in(id:doc_ids)
  end

  # Public: Get extra field value
  # 
  # Returns string
  def extra_field_value(option)
    extra_fields[option.to_sym] if extra_fields.present?
  end
end