class Therapy
  include Mongoid::Document
  include Mongoid::Timestamps
  
  field :name,                    type: String, default: ""  
  field :status,                  type: Integer, default: 1

  has_many :vpd_therapies
  has_many :trials

  validates_presence_of :name
  validates_uniqueness_of :name, :case_sensitive => false
 
  scope :activated_therapies, -> { where(status: 1) }

  # Public: Get all activated trials of this sponsor
  # 
  # Returns trials
  def activated_trials
    trials.activated_trials
  end

  # Public: Get all sites of this sponsor
  # 
  # Returns sites
  def sites
    trial_ids = activated_trials.map(&:id)
    Site.in(trial_id: trial_ids)
  end

  # Public: Get all completed sites of this sponsor
  # 
  # Returns sites
  def completed_sites
    site_ids = []
    sites.each do |site|
      site_ids << site.id if site.completed?
    end
    Site.in(id:site_ids)
  end

end