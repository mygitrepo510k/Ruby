class Trial
  include Mongoid::Document
  include Mongoid::Timestamps

  field :title,         type: String, default: '' # trial vpd
  field :nct,           type: String, default: '' # trial nct
  field :trial_id,      type: String              # trial ID
  field :status,        type: Integer, default: 1 # active/disable

  field :extra_fields,  type: Hash # extra fields for trial(about trial)

  belongs_to :vpd
  belongs_to :sponsor
  belongs_to :vpd_sponsor

  has_many :roles,  as: :rolify, dependent: :destroy
  has_many :sites,  dependent: :destroy

  has_many :trial_binders,        dependent: :destroy
  has_many :trial_documents,      dependent: :destroy

  belongs_to :therapy
  belongs_to :vpd_therapy

  belongs_to :phase
  belongs_to :vpd_phase

  scope :activated_trials, -> {where(status: 1)}

  validates_presence_of :trial_id, :vpd_id
  validates_uniqueness_of :trial_id, scope: :vpd_id, case_sensitive: false

  # Public: Get all activated site users of this trial
  # 
  # Returns users
  def users
    user_ids = []
    self.sites.each do |site|
      user_ids << site.roles.map(&:user_id) # get all site user ids
    end
    User.in(id: user_ids.flatten)
  end

  # Public: Get all activated trial admins and trial associates of this trial
  # 
  # Returns users
  def trial_admins
    user_ids = roles.activated_roles.map(&:user_id)
    User.in(id: user_ids.flatten)
  end

  # Public: Check if the given user is real trial admin in this trial
  # 
  # Returns boolean value
  def trial_admin?(user)
    roles.activated_roles.where(user: user, role: Role::ROLES[:trial_admin]).first.present?
  end

  # Public: Check if the given user is real trial read only or not in this trial
  # user - User object 
  # Returns boolean value
  def trial_readonly?(user)
    roles.activated_roles.where(user: user, role: Role::ROLES[:trial_readonly]).first.present?
  end

  # Public: Get sponsor name
  # 
  # Returns name string
  def sponsor_name
    sponsor.present? ? sponsor.name : ''
  end

  # Public: Get role name of given user
  # user - user object
  # Returns role name string of user object
  def role_name_by_user(user)
    if user.super_admin?
      "SUPADM"
    elsif user.vpd_admin?(self)
      "VPDADM"
    else
      role = role_by_user(user)
      if role.present?
        role.role_label
      else
        roles = roles_by_user(user)
        if roles.count == 0
          "Disabled"
        else
          roles = roles.sort_by!{|r| r.role}
          role_names = roles.map { |r| r.role_label }
          role_names.uniq
        end
      end
    end
  end

  # Public: Get trial role of given user in this trial
  # user - user object
  # Returns role object
  def role_by_user(user)
    role = self.roles.activated_roles.where(user: user).first
    role if role.present? # trial role
  end

  # Public: Get roles of given user in this trial
  # user - user object
  # Returns role object
  def roles_by_user(user)
    site_ids = sites.activated_sites.map(&:id)
    roles = Role.in(rolify_id: site_ids).activated_roles.where(user: user)
  end

  STATUS = %w(Disabled Acitve)
  # Public: Get status label of this trial
  #
  # Returns status string
  def status_label
    STATUS[status]
  end

  # Public: Get extrafield value
  #
  # Returns string
  def extra_field_value(option)
    extra_fields[option.to_sym] if extra_fields.present?
  end

  # Public: Set trial Id as CAPs
  #
  # Returns status string 
  def trial_id=(val)
    self[:trial_id] = val.upcase
  end

  def vpd_countries
    country_ids = sites.activated_sites.map(&:vpd_country_id)
    VpdCountry.in(id: country_ids)
  end

  def documents
    document_ids = []
    sites.activated_sites.each do |site|
      document_ids << site.documents.map(&:id)
    end 
    Document.in(id:document_ids.flatten)
  end

end