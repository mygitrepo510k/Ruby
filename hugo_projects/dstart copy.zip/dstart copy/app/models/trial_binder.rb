class TrialBinder
  include Mongoid::Document
  include Mongoid::Timestamps
  
  field :binder_id,         type: String,   default: ""
  field :document_ids,      type: String,   default: ""
  field :status,            type: Integer,  default: 1


  belongs_to :vpd
  belongs_to :vpd_binder
  belongs_to :trial

  has_many :trial_documents
  has_many :binders
  
  validates_presence_of :binder_id, :trial_id, :vpd_id
  validates_uniqueness_of :binder_id, scope: :trial_id, :case_sensitive => false  

  def sites
    site_ids = []
    binders.each do |binder|
      site_ids << binder.site.id.to_s
    end
    Site.in(id:site_ids).not_in(status:0)
  end

  def completed_binders    
    binder_ids = []
    binders.each do |binder|
      binder_ids << binder.id.to_s if binder.completed?
    end
    Binder.in(id:binder_ids).not_in(status:0)
  end

  def documents
    ids = document_ids.split(",")
    TrialDocument.in(id:ids).not_in(status:0)
  end
  
  def avg_time
    completed_binder_days = []
    binders.each do |binder|
      completed_binder_days << binder.completed_day if binder.completed?
    end
    completed_binder_days.count > 0 ? completed_binder_days.sum : "N/A"
  end

  def status_name
    if status == 1
      "Active"
    else
      "Disabled"
    end
  end
end