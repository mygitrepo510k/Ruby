class TrialDocument
  include Mongoid::Document
  include Mongoid::Timestamps
  
  field       :status,                  type: Integer, default: 1
  # field       :document_id,             type: String, default: ""
  field       :document_type,           type: Integer, default: 0
  field       :name,                    type: String, default: ""
  field       :content,                 type: String, default: ""
  field       :document_version,        type: String, default: "1.0"

  # field       :due_date,                type: Date
  field       :due_days,                type: Integer, default: 1

  field       :play_book,               type: String
  field       :document_mode,           type: Integer
  belongs_to  :vpd
  belongs_to  :vpd_document

  belongs_to  :trial
  belongs_to  :trial_binder

  has_many :documents
  has_many :document_versions,      dependent: :destroy  
  has_many :document_files,         dependent: :destroy

  validates_presence_of :name, :trial_id, :vpd_id, :document_type
  # validates_uniqueness_of :document_id, scope: :trial_id
  
  scope :activated_trial_documents, -> {where(status: 1)}

  def cur_document_version
    cur_version = document_versions.where(document_version:document_version).first    
  end

  def sites
    site_ids = []
    documents.not_in(state:0).each do |site_doc|
      site_ids << site_doc.site.id.to_s
    end
    Site.in(id:site_ids).not_in(status:0)
  end

  def completed_docs
    doc_ids = []
    documents.not_in(state:0).each do |site_doc|
      doc_ids << site_doc.id.to_s if site_doc.is_completed
    end
    Document.in(id:doc_ids).not_in(state:0)
  end

  def avg_time
    completed_docs_days = []
    completed_docs.each do |site_doc|
      completed_docs_days << site_doc.completed_day if site_doc.is_completed
    end
    completed_docs_days.count > 0 ? completed_docs_days.sum : "N/A"
  end

  def type_name
    VpdDocument::DOCUMENT_TYPES[document_type]
  end
end