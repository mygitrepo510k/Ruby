class User
  include Mongoid::Document
  include Mongoid::Timestamps

  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable, :confirmable,
         :recoverable, :rememberable, :trackable, :validatable, :timeoutable, timeout_in: 30.minutes

  ## Database authenticatable
  field :email,              type: String, default: ""
  field :encrypted_password, type: String, default: ""

  ## Recoverable
  field :reset_password_token,   type: String
  field :reset_password_sent_at, type: Time

  ## Rememberable
  field :remember_created_at, type: Time

  ## Trackable
  field :sign_in_count,      type: Integer, default: 0
  field :current_sign_in_at, type: Time
  field :last_sign_in_at,    type: Time
  field :current_sign_in_ip, type: String
  field :last_sign_in_ip,    type: String

  # Confirmable
  field :confirmation_token,   type: String
  field :confirmed_at,         type: Time
  field :confirmation_sent_at, type: Time
  field :unconfirmed_email,    type: String # Only if using reconfirmable

  ## Lockable
  # field :failed_attempts, type: Integer, default: 0 # Only if lock strategy is :failed_attempts
  # field :unlock_token,    type: String # Only if unlock strategy is :email or :both
  # field :locked_at,       type: Time

  field :first_name,            type: String, default: ''     # first name
  field :last_name,             type: String, default: ''     # last name
  
  field :title,                 type: String, default: ''     # Not used right now
  field :prdsiplay,             type: String, default: "P"    # Not used right now
  field :curr_pref,             type: String, default: "USD"  # Not used right now

  field :salutation,            type: String, default: "Mr." # Prefix 
  field :organization,          type: String, default: ''     # Organization 
  field :position,              type: String, default: ''     # Position
  field :phone,                 type: String, default: ''     # Phone Number
  field :country,               type: String, default: ''     # Country

  field :member_type,           type: Integer, default: 100   # Refer to above Role::ROLES
  field :status,                type: Integer, default: 1     # active/disable
  field :authentication_token,  type: String                  
  field :profile_id,            type: String                  # profile Id of ePredict Profile table for session sharing

  has_many :roles,              dependent: :destroy

  belongs_to :vpd
  belongs_to :manager,  class_name: "User"
  has_many :members,    class_name: "User", foreign_key:"manager_id"

  scope :activated_users, -> {where(status: 1)}

  validates_presence_of :member_type

  before_save :ensure_authentication_token
  after_create :setup_profile

  # Public: Check if this user is super level user(super admin) or not
  # 
  # Returns boolean value
  def super_admin?
    member_type == Role::ROLES[:super_admin] 
  end

  # Public: Check if this user is vpd level user(vpd admin) or not
  # trial - Trial object. 
  # if trial is selected, check if the user is really vpd admin in that trial.
  # Returns boolean value
  # Note: this user can edit VPD level data
  def vpd_level_user?(trial=nil) 
    if trial.present?
      super_admin?  ||  (member_type == Role::ROLES[:vpd_admin]  &&  trial.vpd == vpd)
    else
      member_type <= Role::ROLES[:vpd_admin]
    end
  end

  # Public: Check if this user is real vpd admin or not
  # trial - Trial object. 
  # Returns boolean value
  # Note: for LHS menus
  def vpd_admin?(trial=nil) 
    if trial.present?
      member_type == Role::ROLES[:vpd_admin]  &&  trial.vpd == vpd 
    else 
      member_type == Role::ROLES[:vpd_admin]  && vpd.present?
    end
  end

  # Public: Check if this user is trial level user(trial admin or trial readonly) or not
  # trial - Trial object. 
  # Returns boolean value
  def trial_level_user?(trial=nil)
    if trial.present?
      vpd_level_user?(trial) || trial.trial_admin?(self) || trial.trial_readonly?(self)
    else
      member_type <= Role::ROLES[:trial_readonly]
    end
  end

  # Public: Check if this user can edit trial level or not
  # trial - Trial object. 
  # Returns boolean value
  def trial_editable?(trial)
    trial_level_user?(trial) && !trial.trial_readonly?(self)
  end

  # Public: Check if this user can edit trial level or not
  # site - Site object. 
  # Returns boolean value
  def site_level_user?(site=nil)
    if site.present?
      return true if trial_level_user?(site.trial)
      role = roles.activated_roles.where(rolify_type: Site, rolify: site).first
      role.role <= Role::ROLES[:site_user]
    else
      member_type <= Role::ROLES[:site_user]
    end
  end

  # Public: Check if this user can edit site details
  # site - Site object. 
  # Returns boolean value
  def site_editable?(site)
    site_level_user?(site) && !site.trial.trial_readonly?(self) && !site.site_readonly?(self)
  end

  # Public: Check if this user is higher than trial associate
  # site - Site object
  # Returns boolean value
  def tcm_level_user?(site)
    trial_editable?(site.trial) || site.trial_associate?(self)
  end

  # Public: Get activated trials of this user with his role
  #
  # Returns trials
  def trials
    roles = self.roles.activated_roles
    trial_ids = roles.map{ |r| r.trial.present? ? r.trial.id : '' }
    if super_admin?
      trial_ids << Trial.all.map(&:id)
    elsif vpd_admin?
      trial_ids << vpd.trials.map(&:id)
    end
    Trial.in(id: trial_ids.flatten.compact.uniq).activated_trials
  end

  # Public: Get all trials (including disabled trials) of this user with his role
  #
  # Returns trials
  def all_trials
    roles = self.roles
    trial_ids = roles.map{ |r| r.trial.present? ? r.trial.id : '' }
    if super_admin?
      trial_ids << Trial.all.map(&:id)
    elsif vpd_admin?
      trial_ids << vpd.trials.map(&:id)
    end
    Trial.in(id: trial_ids.flatten.compact.uniq)
  end

  # Public: Get all sites of this user with his role
  #
  # Returns sites
  # Note: if site count is 1, user will go to site panel after login
  def sites
    roles = self.roles.activated_roles
    site_ids = roles.map{ |r| r.site.present? ? r.site.id : '' } 
    Site.in(id: site_ids.compact.uniq).activated_sites
  end

  # Public: Get all sites with trial
  # 
  # Returns sites
  # Note: if the site count is 1, after login
  def sites_of_trial(trial)
    sites.where(trial: trial).activated_sites
  end  

  # Public: Get role of this user in the given trial
  # 
  # Returns Role Object
  def trial_role(trial)
    role = trial.role_by_user(self)
  end

  # Public: Get role of this user in the given site
  # 
  # Returns Role Object
  def site_role(site)
    roles.activated_roles.where(rolify: site).first
  end

  # Public: Check if the user has his own profile or not
  # 
  # Returns boolean value
  def has_profile?
    first_name.present? && last_name.present?    
  end

  # Public: Get full name of user
  #
  # Returns full name string
  def name
    name = [first_name, last_name].join(" ")
    name.present? ? name : email
  end

  # Public: Remove user roles in the given vpd
  def remove_roles_in_vpd(vpd)
    roles.where(rolify_type: Trial).in(rolify_id: vpd.trials.map{|t| t.id }).destroy_all
    site_ids = []
    vpd.trials.each do |trial|
      site_ids << trial.sites.map { |s| s.id }
    end
    roles.where(rolify_type: Site).in(rolify_id: site_ids.flatten.compact).destroy_all    
  end

  # Public: Remove user roles in the given trial
  def remove_roles_in_trial(trial)
    roles.where(rolify_type: Trial, rolify_id: trial.id).destroy_all
    roles.where(rolify_type: Site).in(rolify_id: trial.sites.map{ |s| s.id }).destroy_all
  end

  # Public: Remove user roles in the given site
  def remove_roles_in_site(site)
    roles.where(rolify_type: Site, rolify_id: site.id).destroy_all
  end

  # Public: Reset password in email confirmation
  #
  # Returns boolean value
  def attempt_set_password(params)
    p = {}
    p[:password] = params[:password]
    p[:password_confirmation] = params[:password_confirmation]
    update_attributes(p)
  end

  # Public: Check if password exists or not
  #
  # Returns boolean value
  def has_no_password?
    self.encrypted_password.blank?
  end

  # Public: new function to provide access to protected method unless_confirmed
  def only_if_unconfirmed
    pending_any_confirmation {yield}
  end

  # Public: Make authentication_token
  #
  # Returns token string
  def ensure_authentication_token
    self.authentication_token ||= generate_authentication_token
  end

  # Public: Get elapsed time from last login
  #
  # Returns array of days, hours, minutes and seconds
  def time_span_in_DHMS
    time1 = Time.now
    time2 = last_sign_in_at
    days, remaining = (time1 - time2).to_i.abs.divmod(86400)
    hours, remaining = remaining.divmod(3600)
    minutes, seconds = remaining.divmod(60)
    [days, hours, minutes, seconds]
  end

  # Public: Get last logged in time string of current user
  #
  # Returns time string
  def last_login
    if last_sign_in_at.present?
      distance = self.time_span_in_DHMS
      if distance[0] > 1
        return distance[0].to_s + "d"
      elsif distance[1] > 1
        return distance[1].to_s + "h(s)"
      else
        "Online"
      end
    else
      "N/A"
    end
  end

  STATUS = %w(Disabled Acitve)
  # Public: Get status label of current user
  #
  # Returns status string
  def status_label
    STATUS[status]
  end

  # Public: Reset the user's profile(dProfile)
  #
  # Returns boolean value  
  def reset_profile
    user = self
    params = {}
    
    params[:token] = profile_token
    params[:profile] = {
      email:              user.email,
      first_name:         user.first_name.present? ? user.first_name : ' ',
      last_name:          user.last_name.present? ? user.last_name : ' ',
      salutation:         user.salutation,
      organization:       user.organization,
      position:           user.position,
      phone:              user.phone,
      country:            user.country,
      profile_type:       Dstart::Application::CONSTS[:app_name].downcase, 
      encrypted_password: user.encrypted_password
    }

    host = Rails.env.development? ? Dstart::Application::CONSTS[:dev_profile_host] : Dstart::Application::CONSTS[:profile_host]  
    uri = URI.parse("#{host}/api/v1/profiles/profile")
    http = Net::HTTP.new(uri.host,uri.port)
    request = Net::HTTP::Post.new(uri.path, initheader = {'Content-Type' =>'application/json'})    
    request.body = "#{params.to_json}"
    result = http.request(request)
    result = JSON.parse(result.body)
    user.profile_id = result["success"]["profile_id"] if result["success"].present?
    user.save
  end

  # Public: Get user's profile from dProfile profile database and set up
  # This api call is done when new user is created
  # Returns boolean value  
  def setup_profile(confirm_needed=true)
    host    = Rails.env.development? ? Dstart::Application::CONSTS[:dev_profile_host] : Dstart::Application::CONSTS[:profile_host]
    url     = URI.parse("#{host}/api/v1/profiles/profile?email=#{email}&token=#{profile_token}")
    result  = JSON.parse Net::HTTP.get(url)    
    user    = self
    if result["success"].present?
      user_info               = result["success"]["profile"]
      profile_id              = result["success"]["profile_id"]
      
      user.first_name         = user_info["first_name"]
      user.last_name          = user_info["last_name"]
      user.organization       = user_info["organization"]
      user.position           = user_info["position"]
      user.phone              = user_info["phone"]
      user.country            = user_info["country"]
      user.salutation         = user_info["salutation"]
      user.profile_id         = profile_id
      user.encrypted_password = user_info["encrypted_password"]
    else
      user.profile_id         = user.id.to_s
    end
    user.send_confirmation_instructions if confirm_needed
    user.save
  end

  # Public: Get user's documents for sending document status
  def documents
    document_ids = []
    roles.activated_roles.each do |role|
      document_ids << role.rolify.documents.map(& :id)
    end
    Document.in(id: document_ids.flatten)
  end

  # Public: Check this user has invalid profile
  # Returns boolean value
  def invalid_profile?
    profile_id.blank? || profile_id == self.id.to_s    
  end

  private

  def profile_token
    Digest::SHA2.hexdigest("Drugdev" + Date.today.to_s)
  end

  # Public: Generate authentication token
  # 
  # Returns token string
  def generate_authentication_token
    loop do
      token = Devise.friendly_token
      break token unless User.where(authentication_token: token).first
    end
  end
end