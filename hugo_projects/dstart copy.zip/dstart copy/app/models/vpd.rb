class Vpd
  include Mongoid::Document
  include Mongoid::Timestamps

  field :name,                  type: String, default: '' # VPD name
  field :status,                type: Integer, default: 1 # active/disable

  # for account data, only can update by super admin.
  field :base_rate,             type: Float, default: 0   # base rate 
  field :per_complete_site,     type: Float, default: 0   # rate per complete site
  field :per_incomplete_site,   type: Float, default: 0   # rate per incomplete site
  # ---------------------------------------------- #

  has_many :vpd_admins,         class_name: "User"
  has_many :trials,             dependent: :destroy

  has_many :vpd_countries,      dependent: :destroy
  has_many :vpd_sponsors,       dependent: :destroy
  has_many :vpd_therapies,      dependent: :destroy
  has_many :vpd_phases,         dependent: :destroy
  has_many :vpd_mail_templates, dependent: :destroy
  has_many :vpd_documents,      dependent: :destroy
  has_many :vpd_binders,        dependent: :destroy
  
  has_many :accounts,             dependent: :destroy
  has_many :options,              dependent: :destroy
  
  scope :activated_vpds, -> {where(status: 1)}

  validates_presence_of :name
  validates_uniqueness_of :name, case_sensitive: false

  # Public: Get all activated trials of this vpd
  # 
  # Returns trials
  def activated_trials
    trials.activated_trials
  end

  # Public: Get all activated sites of this vpd
  # 
  # Returns sites
  def activated_sites
    trial_ids = activated_trials.map(&:id)
    Site.in(trial_id: trial_ids).activated_sites
  end

  # Public: Get all activated users of this vpd
  # 
  # Returns users
  def users
    user_ids = []
    trials.activated_trials.each do |trial|
      user_ids << trial.roles.activated_roles.map(&:user_id)
      trial.sites.activated_sites.each do |site|
        user_ids << site.roles.activated_roles.map(&:user_id)
      end
    end
    User.in(id: user_ids.flatten.uniq)
  end

  # Public: Check if the user is vpd admin of this vpd
  # 
  # Returns boolean
  def vpd_admin?(user)
    vpd_admins.include?(user)
  end

  # Get trial extra fields
  #
  # Returns options object
  def trial_fields
    options.trial_fields
  end

  # Get site extra fields
  #
  # Returns options object
  def site_fields
    options.site_fields
  end

  # Get mailtemplate
  #
  # Returns mailtemplate object
  def mailtemplate(template)
    vpd_mail_templates.where(type:template).first
  end

  # Get sites by month
  #
  # Returns completed sites object
  def sites_by_month(year, month)    
    activated_sites.where("return this.created_at.getFullYear() == #{year.to_i} && this.created_at.getMonth() == #{month.to_i-1}").not_in(status:0)
  end

  # Get completed sites by month
  #
  # Returns completed sites object
  def completed_sites_by_month(year, month)
    site_ids = []
    sites = sites_by_month(year,month)
    sites.each do |site|
      site_ids << site.id.to_s if site.completed?
    end
    Site.in(id:site_ids)
  end

  # Get incompleted sites by month
  #
  # Returns incompleted sites object
  def incompleted_sites_by_month(year, month)
    site_ids = []
    sites = sites_by_month(year,month)
    sites.each do |site|
      site_ids << site.id.to_s unless site.completed?
    end
    Site.in(id:site_ids)
  end

  # This action is called via heroku scheduler
  def self.calculate_account
    if Date.today.at_beginning_of_month == Date.today
      Vpd.each do |vpd|
        complete_sites    = vpd.completed_sites_by_month(Date.today.year, Date.today.month - 1).count * vpd.per_complete_site
        incomplete_sites  = vpd.incompleted_sites_by_month(Date.today.year,Date.today.month - 1).count * vpd.per_incomplete_site
        vpd.accounts.create(
          base_rate:vpd.base_rate,
          per_complete_site:vpd.per_complete_site, 
          per_incomplete_site:vpd.per_incomplete_site, 
          accounting_date:Date.today, 
          complete_sites:complete_sites,
          incomplete_sites:incomplete_sites,
          total:(vpd.base_rate + complete_sites + incomplete_sites))
      end
    end
  end
end