class VpdCountry
  include Mongoid::Document
  include Mongoid::Timestamps

  field :name,    type: String, default: '' # VPD Country name
  field :status,  type: Integer, default: 1 # active/disable

  belongs_to :vpd
  belongs_to :country

  has_many :sites

  scope :activated_countries, -> {where(status: 1)}

  validates_presence_of :vpd_id, :country_id
  validates_uniqueness_of :country_id, scope: :vpd_id

  after_create :set_name

  # Public: Get code of this country
  # 
  # Returns the code value
  def code
    country.code
  end

  # Public: Get all trials of this country
  # 
  # Returns trials
  def trials
    trial_ids = sites.map(&:trial_id)
    Trial.in(id: trial_ids).activated_trials
  end

  # Public: Get all completed sites of this country
  # 
  # Returns sites
  def completed_sites
    site_ids = []
    sites.activated_sites.each do |site|
      site_ids << site.id.to_s if site.completed?
    end
    Site.in(id: site_ids)
  end

  # Public: Get all completed sites of this country
  # 
  # Returns sites
  def cycle_time
    completed_site_days = []
    sites.activated_sites.each do |site|
      completed_site_days << site.completed_day if site.completed?      
    end
    completed_site_days.count > 0  ?  (completed_site_days.sum.to_f / completed_site_days.count).round(1).to_s + " d"  :  "N/A"
  end


  private

  # Private: Set name of country
  def set_name
    self.name = country.name
    save
  end
end