class VpdDocument
  include Mongoid::Document
  include Mongoid::Timestamps
  
  DUE_DAYS       = %w[1\ d 7\ d 14\ d 30\ d 45\ d 60\ d 90\ d]
  DOCUMENT_TYPES = ["Contract", "CDA", "Budget", "Other"]

  field       :status,                  type: Integer, default: 1  
  field       :document_type,           type: Integer, default: 0
  field       :name,                    type: String, default: ""
  field       :content,                 type: String, default: ""
  field       :document_version,        type: String, default: "1.0"
  
  # field       :due_date,                type: Date
  field       :due_days,                type: Integer, default: 1
  
  field       :play_book,               type: String
  field       :document_mode,           type: Integer
  belongs_to  :vpd
  
  has_many :trial_documents
  has_many :document_versions,      dependent: :destroy  
  has_many :document_files,         dependent: :destroy

  validates_presence_of :vpd_id, :document_type
  validates_uniqueness_of :name, scope: [:vpd_id, :document_type]

  scope :activated_vpd_documents, -> {where(status: 1)}

  def cur_document_version
    cur_version = document_versions.where(document_version:document_version).first
  end

  def type_name
    VpdDocument::DOCUMENT_TYPES[document_type]
  end
  
  def sites
    Site.all
    # site_ids = []
    # trial_documents.not_in(status:0).each do |tri_doc|
    #   tri_doc.documents.not_in(state:0).each do |site_doc|
    #     site_ids << site_doc.binder.site.id.to_s
    #   end
    # end
    # Site.in(id:site_ids).not_in(status:0)
  end

  def completed_docs
    # doc_ids = []
    # trial_documents.not_in(status:0).each do |tri_doc|
    #   tri_doc.documents.not_in(state:0).each do |site_doc|
    #     doc_ids << site_doc.id.to_s if site_doc.is_completed
    #   end
    # end
    # Document.in(id:doc_ids).not_in(state:0)
    Document.all
  end

  def avg_time
    completed_docs_days = []
    completed_docs.each do |site_doc|
      completed_docs_days << site_doc.completed_day if site_doc.is_completed
    end
    completed_docs_days.count > 0 ? completed_docs_days.sum : "N/A"
  end
end