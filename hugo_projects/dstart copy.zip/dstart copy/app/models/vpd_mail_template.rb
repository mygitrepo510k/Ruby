class VpdMailTemplate
  include Mongoid::Document
  include Mongoid::Timestamps

  # Can't change this mail templates because this template have not VPD
  # expired_email:                  0,
  # confirmation_email:             1,
  # contact_email:                  2,

  MAIL_TEMPLATES = {  invited_vpd_admin:              3,
                      invited_trial_admin:            4,
                      invited_site_user:              5,
                      changed_trial_role:             6,
                      changed_site_role:              6,
                      changed_user_status:            7,
                      document_notification:          8,
                      add_new_document_notification:  9,
                      changed_document_status:        10,
                      attached_new_file:              11,
                      signed_document:                12,
                      locked_document:                13
                    }

  field :type,                type: Integer
  field :name,                type: String
  field :subject,             type: String

  field :body,                type: String
  field :status,              type: Integer, default: 1

  belongs_to :vpd

  scope :activated_mail_templates, -> {where(status: 1)}

  validates_presence_of   :type, :name
  validates_uniqueness_of :type, scope: :vpd_id

end