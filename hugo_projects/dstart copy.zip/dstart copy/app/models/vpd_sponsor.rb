class VpdSponsor
  include Mongoid::Document
  include Mongoid::Timestamps

  field :name,   type: String, default: ''  # name
  field :status, type: Integer, default: 1  # active/disable

  belongs_to :vpd
  belongs_to :sponsor

  has_many :trials

  scope :activated_sponsors, -> {where(status: 1)}

  validates_presence_of :vpd_id, :sponsor_id
  validates_uniqueness_of :sponsor_id, scope: :vpd_id

  after_create :set_name

  # Public: Get all activated sites of this vpd sponsor
  # 
  # Returns sites
  def sites
    trial_ids = trials.activated_trials.map(&:id)
    Site.in(trial_id: trial_ids).activated_sites
  end

  # Public: Get all completed sites of this vpd sponsor
  # 
  # Returns sites
  def completed_sites
    site_ids = []
    sites.activated_sites.each do |site|
      site_ids << site.id.to_s if site.completed?
    end
    Site.in(id: site_ids)
  end

  private

  # Private: Set name of sponsor
  def set_name
    self.name = sponsor.name
    save
  end
end