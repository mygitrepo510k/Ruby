class VpdTherapy
  include Mongoid::Document
  include Mongoid::Timestamps
  
  field :name,                    type: String, default: ""
  field :status,                  type: Integer, default: 1

  belongs_to :vpd
  belongs_to :therapy  
  has_many :trials
  
  validates_presence_of :vpd_id, :therapy_id
  validates_uniqueness_of :therapy_id, scope: :vpd_id
  
  after_create :set_name
  # Public: Get all activated sites of this vpd sponsor
  # 
  # Returns sites
  def sites
    trial_ids = trials.activated_trials.map(&:id)
    Site.in(trial_id: trial_ids).activated_sites
  end

  # Public: Get all completed sites of this vpd sponsor
  # 
  # Returns sites
  def completed_sites
    site_ids = []
    sites.activated_sites.each do |site|
      site_ids << site.id.to_s if site.completed?
    end
    Site.in(id: site_ids)
  end

  private

  # Private: Set name of sponsor
  def set_name
    self.name = therapy.name
    save
  end
end