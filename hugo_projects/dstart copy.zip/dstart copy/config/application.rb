require File.expand_path('../boot', __FILE__)

# Pick the frameworks you want:
require "active_model/railtie"
# require "active_record/railtie"
require "action_controller/railtie"
require "action_mailer/railtie"
require "action_view/railtie"
require "sprockets/railtie"
require "rails/test_unit/railtie"

# Require the gems listed in Gemfile, including any gems
# you've limited to :test, :development, or :production.
Bundler.require(:default, Rails.env)

module Dstart
  class Application < Rails::Application
    CONSTS = {
      app_name:         "dStart",
      app_host:         "http://dstart.herokuapp.com",
      profile_host:     "http://dprofile.herokuapp.com",
      drugdev_host:     "http://www.drugdev.com",
      contact_email:    "admin@dstart.com",
      log_out:          "dstart_log_out",

      dev_host:         "http://192.168.0.55:3005",
      dev_profile_host: "http://192.168.0.135:3000",
      dev_ip:           "192.168.0.55",
      dev_port:         "3005"
    }

    # Set Time.zone default to the specified zone and make Active Record auto-convert to this zone.
    # Run "rake -D time" for a list of tasks for finding time zone names. Default is UTC.
    # config.time_zone = 'Central Time (US & Canada)'
    require Rails.root.join("lib/custom_public_exceptions")
    config.exceptions_app = CustomPublicExceptions.new(Rails.public_path)

    # The default locale is :en and all translations from config/locales/*.rb,yml are auto loaded.
    # config.i18n.load_path += Dir[Rails.root.join('my', 'locales', '*.{rb,yml}').to_s]
    # config.i18n.default_locale = :de

    config.before_configuration do
      env_file = File.join(Rails.root, 'config', 'app_env.yml')
      YAML.load(File.open(env_file)).each do |key, value|
        ENV[key.to_s] = value
      end if File.exists?(env_file)
    end
  end
end