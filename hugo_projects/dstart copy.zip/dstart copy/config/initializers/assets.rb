# Be sure to restart your server when you modify this file.

# Version of your assets, change this if you want to expire all your assets.
Rails.application.config.assets.version = '1.0'
Rails.application.config.assets.precompile += %w( lib/rangy/rangy-core.js )
Rails.application.config.assets.precompile += %w( ice/polyfills.js )
Rails.application.config.assets.precompile += %w( ice/ice.js )
Rails.application.config.assets.precompile += %w( ice/dom.js )
Rails.application.config.assets.precompile += %w( ice/icePlugin.js )
Rails.application.config.assets.precompile += %w( ice/icePluginManager.js )
Rails.application.config.assets.precompile += %w( ice/bookmark.js )
Rails.application.config.assets.precompile += %w( ice/selection.js )
Rails.application.config.assets.precompile += %w( ice/plugins/IceAddTitlePlugin/IceAddTitlePlugin.js )
Rails.application.config.assets.precompile += %w( ice/plugins/IceCopyPastePlugin/IceCopyPastePlugin.js )
Rails.application.config.assets.precompile += %w( ice/plugins/IceEmdashPlugin/IceEmdashPlugin.js )
Rails.application.config.assets.precompile += %w( ice/plugins/IceSmartQuotesPlugin/IceSmartQuotesPlugin.js )

# Precompile additional assets.
# application.js, application.css, and all non-JS/CSS in app/assets folder are already added.
# Rails.application.config.assets.precompile += %w( search.js )
