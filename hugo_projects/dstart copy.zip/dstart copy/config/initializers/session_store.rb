# Be sure to restart your server when you modify this file.

Dstart::Application.config.session_store :cookie_store, key: "_#{Dstart::Application::CONSTS[:app_name].downcase}_session"