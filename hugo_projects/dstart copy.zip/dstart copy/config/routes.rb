Rails.application.routes.draw do
  devise_for :users, controllers: { registrations: "users/registrations", sessions: "users/sessions", confirmations: "users/confirmations" }
  as :user do
    patch "/user/confirmation" => "confirmations#update", via: :patch, as: :update_user_confirmation
  end

  get "dashboard" => "dashboard#index"

  namespace :dashboard do
    resources :vpds, only: [:index, :new, :create] do
      member do
        get   :trials                     # for all trials in VPD        
        
        get   :admins, :new_admin, :users # for VPD Admins index, new, Directory
        post  :admin                      # for VPD Admin create

        get   :configs                    # for VPD Config
        get   :sponsors                   # for VPD Sponsor
        get   :countries                  # for VPD Country

        get   :vpd_binders                          # for VPD Binders
        get   :vpd_documents                        # for VPD Documents

        get   :accounts                             # for VPD Accounts
        match :set_account, via: [:post, :patch]    # for setting 
        
        match :reports, via: [:get, :post]          # for VPD Reports
        
        get :trial_fields_options                   # for setting for trial extra fields
        get :site_fields_options                    # for setting for trial extra fields

        match :add_option, via: [:post, :patch]     # for create for extra field
        post :change_option_status                  # for change stats for extra field

        get :therapies        
        get :phases
        
      end # end vpds member block

      resources :trials, shallow: true, except: [:index, :destroy] do
        member do
          get   :trial_documents
          get   :trial_binders
          get   :sites                    # for all sites in Trial with trial_id

          get   :admins, :new_admin       # for Trial Admins index, new
          post  :admin                    # for Trial Admin create

          get   :new_upload               # for New config file select dialog
          patch :upload_config            # for New config file upload
        end

        collection do
          get   :sites                    # for all sites in Trial
        end
        resources :sites, shallow: true, except: [:index, :destroy] do
          member do
            get   :users, :new_user, :edit_user # for Site Users(Trial Associate, Site Admin, Site User, Site User(Read Only))
            post  :user                         # for Site User create
            match :role, via: [:put, :patch]    # for Change Site User Role

            get :documents            
          end
          
          resources :documents, shallow: true, only: [:new, :create, :edit, :update] do 
            member do         
              post :update_play_book
              post :verify_document_file
              post :change_status
              post :update_signature

              post :change_document_mode

              post :upload_pdf_to_amazon

              get :view_pdf
              get :export_pdf

            end
          end
        end


      end # end trials resources

      resources :mail_templates

      resources :vpd_binders, shallow: true, only: [:new, :create, :edit, :update]

      resources :vpd_documents, except: [:index, :show, :destroy] do
        member do 
          post :update_document_version
          post :update_play_book
          post :verify_document_file
          post :change_document_mode
        end
      end # end vpd_documents resources

      resources :vpd_options, shallow: true, only: [:new, :create]

    end # end vpds resources

    resources :trials,    only: [:create, :show] do
      resources :trial_binders, only: [:new, :create, :edit, :update]      

      resources :trial_documents, only: [:new, :create, :edit, :update, :destroy] do
        member do
          post :update_document_version
          post :update_play_book
          post :verify_document_file
          post :change_document_mode
        end
      end
    end # end trials resources

    resources :sponsors,  only: [:index, :new, :create]
    resources :countries, only: [:index, :new, :create] do
      collection do
        get :provinces                    # for ajax call to get provinces with country code
      end
    end # end countries resouces
    
    resources :therapies, only: [:index, :new, :create]
    resources :phases, only: [:index, :new, :create]

    post  :update_status
    get   :users, :user_info, :edit_user
    get   :profile
    match :update_user, via: [:put, :patch]
    match :update_profile, via: [:put, :patch]

    get "new_trial"   => "trials#new",    as: :new_trial
  end # end dashboard namespace
  
  get "terms"           => "home#terms"
  get "contact"         => "home#contact"
  get "privacy"         => "home#privacy"
  get "authorization"   => "home#authorization"
  get "session_expire"  => "home#session_expire"

  get "api/v1/accounts/user"      => "home#user"
  post "api/v1/profiles/profile"  => "home#update_user"

  match "/404" => "errors#error404", via: [:get, :post, :patch, :delete]
  
  root "home#index"
end