# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

p "Destroy User"
User.destroy_all
p "Destroy Vpd"
Vpd.destroy_all
p "Destroy Country"
Country.destroy_all
p "Destroy Sponsor"
Sponsor.destroy_all
p "Destroy VpdCountry"
VpdCountry.destroy_all
p "Destroy VpdSponsor"
VpdSponsor.destroy_all
p "Destroy Trial"
Trial.destroy_all
p "Destroy Site"
Site.destroy_all
p "Destroy Role"
Role.destroy_all

p "Create Super admin"
user = User.where(email: Dstart::Application::CONSTS[:contact_email]).first
unless user.present?
  admin = User.create(email: Dstart::Application::CONSTS[:contact_email], password: 'admin321',
    password_confirmation: 'admin321', member_type: Role::ROLES[:super_admin], 
    first_name: 'admin', last_name: 'Ahn', confirmed_at: Time.now)
end