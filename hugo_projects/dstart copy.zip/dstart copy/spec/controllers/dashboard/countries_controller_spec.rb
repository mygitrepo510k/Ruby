require 'rails_helper'

RSpec.describe Dashboard::CountriesController, :type => :controller do

end
