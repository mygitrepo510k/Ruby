require 'rails_helper'

RSpec.describe Dashboard::SitesController, :type => :controller do

end
