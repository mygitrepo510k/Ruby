require 'rails_helper'

RSpec.describe Dashboard::SponsorsController, :type => :controller do

end
