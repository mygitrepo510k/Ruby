require 'rails_helper'

RSpec.describe Dashboard::TrialsController, :type => :controller do

end
