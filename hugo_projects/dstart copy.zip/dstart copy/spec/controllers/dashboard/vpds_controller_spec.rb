require 'rails_helper'

RSpec.describe Dashboard::VpdsController, :type => :controller do

end
