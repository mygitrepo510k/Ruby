require 'rails_helper'

RSpec.describe DashboardController, :type => :controller do

end
