require 'rails_helper'

RSpec.describe Users::ConfirmationsController, :type => :controller do

end
