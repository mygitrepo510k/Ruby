require 'rails_helper'

RSpec.describe Users::RegistrationsController, :type => :controller do

end
