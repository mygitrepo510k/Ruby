require 'rails_helper'

RSpec.describe Users::SessionsController, :type => :controller do

end
