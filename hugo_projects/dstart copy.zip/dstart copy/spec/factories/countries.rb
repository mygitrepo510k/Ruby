FactoryGirl.define do
  factory :country do
    
  end

end
