FactoryGirl.define do
  factory :site do
    
  end

end
