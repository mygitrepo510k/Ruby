FactoryGirl.define do
  factory :sponsor do
    
  end

end
