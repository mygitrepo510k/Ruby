FactoryGirl.define do
  factory :trial do
    
  end

end
