FactoryGirl.define do
  factory :user do
    first_name ""
last_name ""
salution ""
organization ""
position ""
phone ""
country ""
member_type ""
status ""
authentication_token ""
profile_id ""
  end

end
