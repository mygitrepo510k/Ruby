FactoryGirl.define do
  factory :vpd_country do
    
  end

end
