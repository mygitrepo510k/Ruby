FactoryGirl.define do
  factory :vpd_sponsor do
    
  end

end
