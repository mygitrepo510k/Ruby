FactoryGirl.define do
  factory :vpd do
    
  end

end
