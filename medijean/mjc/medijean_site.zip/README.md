# MediJean Cloud
The MediJean Cloud (MJC) is a Ruby on Rails application that powers most user scenarios. This page lays out the requirements and implementation details for this subsystem.

Please see [wiki](/medijean/main/wikis/home) for complete documentation
