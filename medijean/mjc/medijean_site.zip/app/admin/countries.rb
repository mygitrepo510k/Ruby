ActiveAdmin.register Country do
  
end
