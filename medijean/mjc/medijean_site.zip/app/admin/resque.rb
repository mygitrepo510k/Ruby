ActiveAdmin.register_page "Resque Web" do

end