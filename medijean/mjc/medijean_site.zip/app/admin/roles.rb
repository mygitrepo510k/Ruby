ActiveAdmin.register Role do
  
end
