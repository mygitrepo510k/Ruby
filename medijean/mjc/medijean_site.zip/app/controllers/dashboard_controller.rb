class DashboardController < ApplicationController
  def show
    # TODO: manage every dashboard(i.e. users#dashboard) from this action
  end
end
