# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Web::Application.config.secret_token = 'e0e47080974bf739df110a4a813aa8b1d0908e413689ea7e3faff281be5646e15bd4d2bbe66b42612c1511aad560e5be6bbe1e246256bc2224204ba957bc8305'
