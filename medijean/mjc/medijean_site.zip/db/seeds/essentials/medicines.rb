Medicine.find_or_create_by_name_and_price("Strain 1", 7.99)
Medicine.find_or_create_by_name_and_price("Strain 2", 7.99)
Medicine.find_or_create_by_name_and_price("Strain 3", 7.99)
Medicine.find_or_create_by_name_and_price("Strain 4", 7.99)