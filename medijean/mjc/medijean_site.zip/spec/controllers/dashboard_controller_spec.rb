require 'spec_helper'

describe DashboardController do

end
