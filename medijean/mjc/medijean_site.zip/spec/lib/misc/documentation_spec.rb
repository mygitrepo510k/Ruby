require 'spec_helper'

describe "Documentation" do 
  context "project" do
    it "contains documentation for all classes" do

      # YARD::Parser::SourceParser.parse("{lib,app}/**/*.rb")
      # puts "node: #{node.class}"

    end
  end
end