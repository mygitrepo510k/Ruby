require 'spec_helper'

describe KcPage do
  pending "add some examples to (or delete) #{__FILE__}"
end
