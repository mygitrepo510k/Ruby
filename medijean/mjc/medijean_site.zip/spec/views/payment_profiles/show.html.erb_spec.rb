require 'spec_helper'

describe "payment_profiles/show.html.erb" do
  pending "add some examples to (or delete) #{__FILE__}"
end
